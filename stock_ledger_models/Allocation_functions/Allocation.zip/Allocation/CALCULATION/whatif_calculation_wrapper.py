from ..GLOBAL_FILES.get_connection import get_mysql_conn
from ..CALCULATION.calculate_validation import calculate_validation
from ..CALCULATION.calculate import calculate
from ..CALCULATION.calculate_whatif import wif_calculate



#----------------------------------------------------------
# Function to call calculation process for allocation
#----------------------------------------------------------
def do_whatif_calc(conn,I_alloc):
    L_func_name="do_whatif_calc"
    O_status =list()
    try:
        #I_get_mysql_conn = list()
        #I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = calculate_validation(conn,I_alloc,O_status)
        if L_func_call ==True:
            L_func_call = calculate(conn,I_alloc,O_status)
            print("calculate: ",L_func_call)
            if L_func_call ==True:
                L_func_call = wif_calculate(conn,I_alloc,O_status)
                print("whatif_calculate: ",L_func_call)
                return L_func_call
            else:
                print("calculate: ",L_func_call)
                return L_func_call 
        else:
            print("calculate_validation: ",L_func_call)
            return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




#if __name__ == "__main__":
#    I_alloc = 6    #alloc_no
#    L_func_call = do_whatif_calc(I_alloc)    
#    print(L_func_call)

