#from ..GLOBAL_FILES.get_connection import get_mysql_conn
from ..CALCULATION.calculate_validation import calculate_validation
from ..CALCULATION.calculate import calculate



#----------------------------------------------------------
# Function to call calculation process for allocation
#----------------------------------------------------------
def do_calculation(conn,I_alloc):
    L_func_name="do_calculation"
    O_status =list()
    try:
        #I_get_mysql_conn = list()
        #I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = calculate_validation(conn,I_alloc,O_status)
        print("calculate_validate: ",L_func_call)
        if L_func_call ==True:
            L_func_call = calculate(conn,I_alloc,O_status)
            print("calculate: ",L_func_call)
            return L_func_call
        else:
            return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




