from ..INVENTORY_SETUP.update_alloc_ext import update_alloc
from ..INVENTORY_SETUP.load_item_source import load_item
from ..INVENTORY_SETUP.inventory_setup import update_inv,setup_location,setup_item_location
import pandas as pd
import yaml
##################################################################################
#Created By - Priyanshu Pandey                                                   #
#File Name - calculate_validations.py                                            #
#Purpose - For initial mandatory validation before calculation                   #
##################################################################################

#--------------------------------------------------------------
# Function to validate calculation 
#--------------------------------------------------------------

def calculate_validation (conn
                         ,I_alloc
                         ,O_status):
    L_func_name ="calculate_validation"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\calculate_validation_queries.yaml') as fh:
            queries              = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_chk_alloc          = queries['calculate_validation']['Q_chk_alloc']
            Q_chk_error          = queries['calculate_validation']['Q_chk_error']
            Q_rfrsh_err          = queries['calculate_validation']['Q_rfrsh_err']
            Q_chk_load_source    = queries['calculate_validation']['Q_chk_load_source']
            Q_chk_setup_location = queries['calculate_validation']['Q_chk_setup_location']
            Q_chk_item_location  = queries['calculate_validation']['Q_chk_item_location']
            #validations
            Q_chk_rel_date       = queries['calculate_validation']['Q_chk_rel_date']
            Q_itm_loc_status     = queries['calculate_validation']['Q_itm_loc_status']
            Q_min_min_need_y     = queries['calculate_validation']['Q_min_min_need_y']
            Q_min_min_need_n     = queries['calculate_validation']['Q_min_min_need_n']
            Q_inactive_sku_wh    = queries['calculate_validation']['Q_inactive_sku_wh']    
            Q_inactive_item_loc  = queries['calculate_validation']['Q_inactive_item_loc']  
            Q_holdback_unit      = queries['calculate_validation']['Q_holdback_unit']  
            Q_holdback_pct       = queries['calculate_validation']['Q_holdback_pct']  
            Q_no_active_sku_y    = queries['calculate_validation']['Q_no_active_sku_y']  
            Q_no_active_sku_n    = queries['calculate_validation']['Q_no_active_sku_n']  

            mycursor = conn.cursor()
            mycursor.execute("SET SESSION sql_mode = '';")
            #status
            O_status=1

            #checking existing error
            #mycursor.execute(Q_chk_error,(I_alloc,))
            #my_chk_error = mycursor.fetchall()
            #if len(my_chk_error)>0:
            #    #status
            #    O_status=2]
            #    print("my_chk_error: ",O_status)
            #    return False

            #reset error columns
            mycursor.execute(Q_rfrsh_err,(I_alloc,))
            print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
            conn.commit()
            #status
            O_status=3

            #checking alloc header
            df_alloc_head = pd.read_sql(Q_chk_alloc,conn,params=(I_alloc,))
            if len(df_alloc_head)>0:
                L_alloc_level      = df_alloc_head.alloc_level[0]
                L_release_date     = df_alloc_head.release_date[0]
                L_wh_store_rel_ind = df_alloc_head.wh_store_rel_ind[0]
                L_alloc_criteria   = df_alloc_head.alloc_criteria[0]

                #status
                O_status=4

                if update_inv(conn
                              ,I_alloc
                              ,O_status) == False:
                    #status
                    O_status=5
                    print(O_status)
                    return False

                #status
                O_status=6
                #load source
                mycursor.execute(Q_chk_load_source,(I_alloc,))
                my_chk_load_source = mycursor.fetchall()
                #status
                O_status=7
                if len(my_chk_load_source) == 0:
                    #status
                    O_status=8
                    
                    if load_item(conn 
                                 ,I_alloc
                                 ,O_status) == False:
                        #status
                        O_status=9
                        print(O_status)
                        return False

                    #setup destination items
                    mycursor.execute(Q_chk_item_location,(I_alloc,))
                    my_chk_item_location = mycursor.fetchall()
                    if len(my_chk_item_location) == 0:
                        #status
                        O_status=10
                            
                        if setup_item_location(conn
                                                ,I_alloc
                                                ,O_status) == False:
                            #status
                            O_status=11
                            print(O_status)
                            return False
                
                #setup destination
                mycursor.execute(Q_chk_setup_location,(I_alloc,))
                my_chk_setup_location = mycursor.fetchall()
                #status
                O_status=12
                if len(my_chk_setup_location) == 0:
                    #status
                    O_status=13
                    if setup_location(conn
                                      ,I_alloc
                                      ,O_status) ==False:
                        #status
                        O_status=14
                        print(O_status)
                        return False

                #--------------
                # validations
                #--------------
                if L_alloc_level == 'T' and L_alloc_criteria == 'W':
                    #status
                    O_status=15

                    #Q_chk_rel_date
                    mycursor.execute(Q_chk_rel_date,(I_alloc,))
                    #status
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    O_status=16
                    #Q_itm_loc_status
                    mycursor.execute(Q_itm_loc_status,(I_alloc,I_alloc))
                    #status
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    O_status=17
                    #Q_inactive_sku_wh
                    mycursor.execute(Q_inactive_sku_wh,(I_alloc,))
                    #status
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    O_status=18

                    #Q_inactive_item_loc
                    mycursor.execute(Q_inactive_item_loc,(I_alloc,I_alloc,I_alloc))
                    #status
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    O_status=19

                    if L_wh_store_rel_ind == 'N':
                        #status
                        O_status=20

                        #Q_no_active_sku_n
                        mycursor.execute(Q_no_active_sku_n,(I_alloc,))
                        print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                        #status
                        O_status=21
                        #Q_min_min_need_n
                        mycursor.execute(Q_min_min_need_n,(I_alloc,I_alloc))
                        print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    else:                        
                        #status
                        O_status=20
                        #Q_no_active_sku_y
                        mycursor.execute(Q_no_active_sku_y,(I_alloc,))
                        print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                        #status
                        O_status=21
                        #Q_min_min_need_y
                        mycursor.execute(Q_min_min_need_y,(I_alloc,I_alloc))
                        print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                #status
                O_status=22
                #Q_holdback_unit
                mycursor.execute(Q_holdback_unit,(I_alloc,))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                #status
                O_status=23
                #Q_holdback_pct
                mycursor.execute(Q_holdback_pct,(I_alloc,))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

            #if recal is Y
            mycursor.execute(Q_chk_error,(I_alloc,))
            my_chk_error = mycursor.fetchall()
            if len(my_chk_error)>0:
                I_input_data = list()
                if update_alloc(conn,
                                O_status,
                                I_alloc,
                                None,
                                None,
                                'Y',
                                I_input_data) ==False:
                    #status
                    O_status=24
                    print(O_status,"- update_alloc failed")
                    conn.rollback()
                    return False
                else:
                    conn.commit()
                    print("Validation Error")
                    return False
            else:
                conn.commit()
                return True

    except Exception as error:
        if O_status<=5:
            print(L_func_name,":",O_status,":","Exception occured while processing fetch_inventory: ", error)
        elif O_status>=6 and O_status<=9:
            print(L_func_name,":",O_status,":","Exception occured while processing load_item: ", error)
        elif O_status<=11 and O_status>=10:
            print(L_func_name,":",O_status,":","Exception occured while processing setup_item_location: ", error)
        elif O_status>=12 and O_status<=14:
            print(L_func_name,":",O_status,":","Exception occured while processing setup_location: ", error)
        elif O_status==24:
            print(L_func_name,":",O_status,":","Exception occured while processing update_alloc: ", error)
        elif O_status>14 and O_status<24:
            print(L_func_name,":",O_status,":","Exception occured while executing validations: ", error)
        else:
            print("Exception occured in: ",L_func_name,error)
        conn.rollback()
        return False





