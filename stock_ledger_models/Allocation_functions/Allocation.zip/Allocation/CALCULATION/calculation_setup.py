from ..GLOBAL_FILES.convert_numpy_64 import convert_numpy
from datetime import datetime
import pandas as pd
import yaml

##################################################################################
#Created By - Priyanshu Pandey                                                   #
#File Name - calculation_setup.py                                                #
#Purpose - setup all inv buckets before final calculation                        #
##################################################################################

#------------------------------------------------------------------------
# Function to populate calc destination before calculation(pop_exclusion)
#------------------------------------------------------------------------

def pop_calc_destination(conn
                         ,I_alloc
                         ,O_status):
    L_func_name ="pop_calc_destination"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\calculation_setup_queries.yaml') as fh:
            queries                   = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_chk_alloc               = queries['pop_calc_destination']['Q_chk_alloc']
            Q_rfrsh_allitemloc        = queries['pop_calc_destination']['Q_rfrsh_allitemloc']
            Q_fetch_allitemloc        = queries['pop_calc_destination']['Q_fetch_allitemloc']
            Q_insert_calc_destination = queries['pop_calc_destination']['Q_insert_calc_destination']
            Q_del_calc_destination    = queries['pop_calc_destination']['Q_del_calc_destination']

            #status
            O_status = 1

            mycursor = conn.cursor()
            #reset error columns
            df_alloc_head = pd.read_sql(Q_chk_alloc,conn,params=(I_alloc,))
            #status
            O_status = 2

            if len(df_alloc_head)>0:
                #status
                O_status = 3

                L_alloc_level      = df_alloc_head.alloc_level[0]
                L_wh_store_rel_ind = df_alloc_head.wh_store_rel_ind[0]
                L_alloc_criteria   = df_alloc_head.alloc_criteria[0]

                #Q_rfrsh_allitemloc
                mycursor.execute(Q_rfrsh_allitemloc,(I_alloc,L_wh_store_rel_ind))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                conn.commit()
                #status
                O_status = 4

            #Q_fetch_allitemloc
            df_allitemloc = pd.read_sql(Q_fetch_allitemloc,conn,params=(I_alloc,))
            #status
            O_status = 5

            if len(df_allitemloc)>0:
                #del_calc_destination for alloc no
                mycursor.execute(Q_del_calc_destination,(I_alloc,))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                conn.commit()
                #status
                O_status = 6

                for i in range(len(df_allitemloc)):

                    L_insert_calc_destination = (df_allitemloc.loc[i, "alloc_no"],               df_allitemloc.loc[i, "item_type"],            df_allitemloc.loc[i, "source_item"],              
                                                 df_allitemloc.loc[i, "source_item_level"],      df_allitemloc.loc[i, "source_tran_level"],    df_allitemloc.loc[i, "source_pack_ind"],        
                                                 df_allitemloc.loc[i, "source_diff1_id"],        df_allitemloc.loc[i, "source_diff2_id"],      df_allitemloc.loc[i, "source_diff3_id"],        
                                                 df_allitemloc.loc[i, "source_diff4_id"],        df_allitemloc.loc[i, "tran_item"],            df_allitemloc.loc[i, "tran_item_level"],     
                                                 df_allitemloc.loc[i, "tran_tran_level"],        df_allitemloc.loc[i, "tran_pack_ind"],        df_allitemloc.loc[i, "tran_diff1_id"],       
                                                 df_allitemloc.loc[i, "tran_diff2_id"],          df_allitemloc.loc[i, "tran_diff3_id"],        df_allitemloc.loc[i, "tran_diff4_id"],      
                                                 df_allitemloc.loc[i, "hier1"],                  df_allitemloc.loc[i, "hier2"],                df_allitemloc.loc[i, "hier3"],               
                                                 df_allitemloc.loc[i, "to_loc"],                 df_allitemloc.loc[i, "to_loc_type"],          df_allitemloc.loc[i, "to_loc_name"],         
                                                 df_allitemloc.loc[i, "sister_store"],           df_allitemloc.loc[i, "sister_store_weight"],  df_allitemloc.loc[i, "assign_default_wh"],   
                                                 df_allitemloc.loc[i, "clear_ind"],              df_allitemloc.loc[i, "item_loc_status"],      df_allitemloc.loc[i, "size_profile_qty"],    
                                                 df_allitemloc.loc[i, "total_profile_qty"],      df_allitemloc.loc[i, "stock_on_hand"],        df_allitemloc.loc[i, "on_order"],            
                                                 df_allitemloc.loc[i, "on_alloc"],               df_allitemloc.loc[i, "alloc_out"],            df_allitemloc.loc[i, "in_transit_qty"],
                                                 df_allitemloc.loc[i, "backorder_qty"],          df_allitemloc.loc[i, "need_value"],           df_allitemloc.loc[i, "rloh_current_value"],
                                                 df_allitemloc.loc[i, "rloh_future_value"],      df_allitemloc.loc[i, "like_source_item"],     df_allitemloc.loc[i, "like_source_item_level"],
                                                 df_allitemloc.loc[i, "like_source_tran_level"], df_allitemloc.loc[i, "like_source_pack_ind"], df_allitemloc.loc[i, "like_source_diff1_id"],   
                                                 df_allitemloc.loc[i, "like_source_diff2_id"],   df_allitemloc.loc[i, "like_source_diff3_id"], df_allitemloc.loc[i, "like_source_diff4_id"],   
                                                 df_allitemloc.loc[i, "like_tran_item"],         df_allitemloc.loc[i, "like_tran_item_level"], df_allitemloc.loc[i, "like_tran_tran_level"],  
                                                 df_allitemloc.loc[i, "like_tran_pack_ind"],     df_allitemloc.loc[i, "like_tran_diff1_id"],   df_allitemloc.loc[i, "like_tran_diff2_id"],     
                                                 df_allitemloc.loc[i, "like_tran_diff3_id"],     df_allitemloc.loc[i, "like_tran_diff4_id"],   df_allitemloc.loc[i, "like_hier1"],              
                                                 df_allitemloc.loc[i, "like_hier2"],             df_allitemloc.loc[i, "like_hier3"],           df_allitemloc.loc[i, "like_pack_no"],           
                                                 df_allitemloc.loc[i, "like_item_weight"],       df_allitemloc.loc[i, "like_size_prof_ind"],   df_allitemloc.loc[i, "create_id"],              
                                                 df_allitemloc.loc[i, "create_datetime"],        df_allitemloc.loc[i, "last_update_id"],       df_allitemloc.loc[i, "last_update_datetime"])
                    #insert calc destination
                    L_insert_calc_destination = convert_numpy(L_insert_calc_destination)

                    mycursor.execute(Q_insert_calc_destination,L_insert_calc_destination)                                                      
                    conn.commit()
                    #status
                    O_status = 7
                return True


    except Exception as argument:
        print(L_func_name,O_status)
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return False


#--------------------------------------------------------------
# Function to populate inventory buckets before calculation
#--------------------------------------------------------------

def pop_inv_buckets(conn
                    ,I_alloc
                    ,O_status):
    L_func_name ="pop_inv_buckets"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\calculation_setup_queries.yaml') as fh:
            queries                = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_chk_alloc            = queries['pop_calc_destination']['Q_chk_alloc']
            Q_fetch_rule           = queries['pop_inv_buckets']['Q_fetch_rule']
            Q_merge_soh            = queries['pop_inv_buckets']['Q_merge_soh']
            Q_merge_tsf_in_transit = queries['pop_inv_buckets']['Q_merge_tsf_in_transit']
            Q_merge_tsf_on_alloc   = queries['pop_inv_buckets']['Q_merge_tsf_on_alloc']
            Q_merge_on_order       = queries['pop_inv_buckets']['Q_merge_on_order']
            Q_merge_ord_on_alloc   = queries['pop_inv_buckets']['Q_merge_ord_on_alloc']
            Q_merge_alloc_out      = queries['pop_inv_buckets']['Q_merge_alloc_out']

            mycursor = conn.cursor()
            #status
            O_status = 1
            
            df_alloc_head = pd.read_sql(Q_chk_alloc,conn,params=(I_alloc,))
            #status
            O_status = 2
            if len(df_alloc_head)>0:
                #status
                O_status = 3
                L_alloc_level      = df_alloc_head.alloc_level[0]
                L_alloc_criteria   = df_alloc_head.alloc_criteria[0]

                #Q_fetch_rule
                df_alloc_rule = pd.read_sql(Q_fetch_rule,conn,params=(I_alloc,))
                L_on_order_commit_date = df_alloc_rule.commit_date[0]

                #status
                O_status = 3.5

                if L_alloc_level =='T':
                    #status
                    O_status = 4
                    #merging stock_on_hand & in_transit_qty & alloc_out
                    mycursor.execute(Q_merge_soh,(I_alloc,I_alloc))
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    conn.commit()
                    #status
                    O_status = 5

                    #Q_merge_tsf_in_transit
                    mycursor.execute(Q_merge_tsf_in_transit,(I_alloc,I_alloc))
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    conn.commit()
                    #status
                    O_status = 6

                    #Q_merge_tsf_on_alloc
                    mycursor.execute(Q_merge_tsf_on_alloc,(I_alloc,L_on_order_commit_date))
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    conn.commit()
                    #status
                    O_status = 7
                    
                    mycursor.execute(Q_merge_on_order,(I_alloc,I_alloc,L_on_order_commit_date,L_on_order_commit_date))
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    conn.commit()
                    #status
                    O_status = 8

                    #Q_merge_ord_on_alloc
                    mycursor.execute(Q_merge_ord_on_alloc,(I_alloc,I_alloc,L_on_order_commit_date,L_on_order_commit_date))
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    conn.commit()
                    #status
                    O_status = 9

                    #Q_merge_alloc_out
                    mycursor.execute(Q_merge_alloc_out,(I_alloc,I_alloc,L_on_order_commit_date,L_on_order_commit_date,L_on_order_commit_date))
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    conn.commit()
                    #status
                    O_status = 10

                return True

    except Exception as error:
        if O_status<=3:
            print(L_func_name,":",O_status,":","Exception occured while fetching rule records: ", error)
        elif O_status==4:
            print(L_func_name,":",O_status,":","Exception occured while merging stock-on-hand: ", error)
        elif O_status==5:
            print(L_func_name,":",O_status,":","Exception occured while merging tsf-in-transit: ", error)
        elif O_status==6:
            print(L_func_name,":",O_status,":","Exception occured while merging tsf-on-alloc: ", error)
        elif O_status==7:
            print(L_func_name,":",O_status,":","Exception occured while merging on-order: ", error)
        elif O_status==8:
            print(L_func_name,":",O_status,":","Exception occured while merging on-order-on-alloc: ", error)
        elif O_status==9:
            print(L_func_name,":",O_status,":","Exception occured while merging alloc out: ", error)
        else:
            print(L_func_name,":",O_status,"Exception occured in: ",L_func_name,error)
        conn.rollback()
        return False


#--------------------------------------------------------------
# Function to populate calc needs temp before calculation
#--------------------------------------------------------------

def seed_calc_need(conn
                   ,I_alloc
                   ,O_status):
    L_func_name ="seed_calc_need"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\calculation_setup_queries.yaml') as fh:
            queries                  = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_insert_calc_need_temp  = queries['seed_calc_need']['Q_insert_calc_need_temp']
            Q_fetch_rule_row         = queries['seed_calc_need']['Q_fetch_rule_row']
            Q_fetch_destination_temp = queries['seed_calc_need']['Q_fetch_destination_temp']
            Q_chk_alloc              = queries['pop_calc_destination']['Q_chk_alloc']
            Q_del_calc_need          = queries['seed_calc_need']['Q_del_calc_need']
            Q_chk_calc_seed_table    = queries['seed_calc_need']['Q_chk_calc_seed_table']
            Q_create_calc_seed_temp  = queries['seed_calc_need']['Q_create_calc_seed_temp']

            mycursor = conn.cursor()
            #status
            O_status = 1
            #Q_chk_allitemloc_table
            df_chk = pd.read_sql(Q_chk_calc_seed_table,conn)
            L_chk = df_chk.chk[0]
            mycursor.execute(Q_create_calc_seed_temp)
            
            if L_chk == 1:
                #status
                O_status =3
                print(" Please drop the table alloc_calc_need_temp")
                print(O_status,L_func_name)
                return False

            #alloc level
            df_alloc_head=pd.read_sql(Q_chk_alloc,conn,params=(I_alloc,))
            #status
            O_status = 2
            if len(df_alloc_head)>0:
                L_alloc_level = df_alloc_head.alloc_level[0]
                #status
                O_status = 3

            #alloc rule level
            df_alloc_rule = pd.read_sql(Q_fetch_rule_row,conn,params=(I_alloc,))
            #status
            O_status = 4

            if len(df_alloc_rule)>0:
                
                L_rule_level = df_alloc_rule.rule_level[0]
                #status
                O_status = 4.5
                
                if L_alloc_level =='T' and L_rule_level =='S':  #sku
                    #status
                    O_status = 5
                   #Q_fetch_destination_temp
                    df_calc_dest = pd.read_sql(Q_fetch_destination_temp,conn,params=(L_rule_level,I_alloc))
                    #status
                    O_status = 6
                    if len(df_calc_dest)>0:
                        #Q_del_calc_need
                        mycursor.execute(Q_del_calc_need,(I_alloc,))
                        print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                        #status
                        O_status = 7
                        

                        for i in range(len(df_calc_dest)):

                            L_insert_calc_need = (df_calc_dest.loc[i, "alloc_no"],               df_calc_dest.loc[i, "rule_many_to_one_id"],    df_calc_dest.loc[i, "rule_level"],
                                                  df_calc_dest.loc[i, "hier1"],                  df_calc_dest.loc[i, "hier2"],                  df_calc_dest.loc[i, "hier3"],
                                                  df_calc_dest.loc[i, "source_item"],            df_calc_dest.loc[i, "source_item_level"],      df_calc_dest.loc[i, "source_tran_level"],    
                                                  df_calc_dest.loc[i, "source_pack_ind"],        df_calc_dest.loc[i, "source_diff1_id"],        df_calc_dest.loc[i, "source_diff2_id"],     
                                                  df_calc_dest.loc[i, "source_diff3_id"],        df_calc_dest.loc[i, "source_diff4_id"],        df_calc_dest.loc[i, "tran_item"],            
                                                  df_calc_dest.loc[i, "tran_item_level"],        df_calc_dest.loc[i, "tran_tran_level"],        df_calc_dest.loc[i, "tran_pack_ind"],        
                                                  df_calc_dest.loc[i, "tran_diff1_id"],          df_calc_dest.loc[i, "tran_diff2_id"],          df_calc_dest.loc[i, "tran_diff3_id"],        
                                                  df_calc_dest.loc[i, "tran_diff4_id"],          df_calc_dest.loc[i, "to_loc"],                 df_calc_dest.loc[i, "sister_store"],           
                                                  df_calc_dest.loc[i, "sister_store_weight"],    df_calc_dest.loc[i, "size_profile_qty"],       df_calc_dest.loc[i, "total_profile_qty"],     
                                                  df_calc_dest.loc[i, "eow_date"],               df_calc_dest.loc[i, "weight"],                 df_calc_dest.loc[i, "sales_hist_need"],     
                                                  df_calc_dest.loc[i, "forecast_need"],          df_calc_dest.loc[i, "replan_need"],            df_calc_dest.loc[i, "plan_need"],       
                                                  df_calc_dest.loc[i, "plan_reproject_need"],    df_calc_dest.loc[i, "receipt_plan_need"],      df_calc_dest.loc[i, "corp_rule_need"],            
                                                  df_calc_dest.loc[i, "like_source_item"],       df_calc_dest.loc[i, "like_source_item_level"], df_calc_dest.loc[i, "like_source_tran_level"], 
                                                  df_calc_dest.loc[i, "like_source_pack_ind"],   df_calc_dest.loc[i, "like_source_diff1_id"],   df_calc_dest.loc[i, "like_source_diff2_id"],   
                                                  df_calc_dest.loc[i, "like_source_diff3_id"],   df_calc_dest.loc[i, "like_source_diff4_id"],   df_calc_dest.loc[i, "like_tran_item"],         
                                                  df_calc_dest.loc[i, "like_tran_item_level"],   df_calc_dest.loc[i, "like_tran_tran_level"],   df_calc_dest.loc[i, "like_tran_pack_ind"],     
                                                  df_calc_dest.loc[i, "like_tran_diff1_id"],     df_calc_dest.loc[i, "like_tran_diff2_id"],     df_calc_dest.loc[i, "like_tran_diff3_id"],     
                                                  df_calc_dest.loc[i, "like_tran_diff4_id"],     df_calc_dest.loc[i, "like_hier1"],             df_calc_dest.loc[i, "like_hier2"],            
                                                  df_calc_dest.loc[i, "like_hier3"],             df_calc_dest.loc[i, "like_pack_no"],           df_calc_dest.loc[i, "like_weight"],            
                                                  df_calc_dest.loc[i, "like_size_prof_ind"],     df_calc_dest.loc[i, "create_id"],              df_calc_dest.loc[i, "create_datetime"],        
                                                  df_calc_dest.loc[i, "last_update_id"],         df_calc_dest.loc[i, "last_update_datetime"])
                            #insert calc destination
                            
                            L_insert_calc_need = convert_numpy(L_insert_calc_need)

                            mycursor.execute(Q_insert_calc_need_temp,L_insert_calc_need)
                            print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                        conn.commit() 
                        #status
                        O_status = 8
                        return True

    except Exception as argument:
        print(L_func_name,O_status)
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return False

#--------------------------------------------------------------
# Function to setup need
#--------------------------------------------------------------

def setup_need(conn
               ,I_alloc
               ,O_status):
    L_func_name ="setup_need"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\calculation_setup_queries.yaml') as fh:
            queries      = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_fetch_rule = queries['setup_need']['Q_fetch_rule']

            mycursor = conn.cursor()
            #status
            O_status = 1

            if seed_calc_need(conn,I_alloc,O_status) == False:
                #status
                O_status = ("seed_calc_need: 2")
                print(O_status)
                return False
            #status
            O_status = 3
            #Q_fetch_rule_type
            df_alloc_rule = pd.read_sql(Q_fetch_rule,conn,params=(I_alloc,))

            if len(df_alloc_rule)>0:
                L_rule_type = df_alloc_rule.rule_type[0]
                #status
                O_status = 4

                #if rule type is history
                if L_rule_type =='H':
                    #status
                    O_status = 5
                    if setup_sales_hist_need(conn,I_alloc,O_status) == False:
                        #status
                        O_status = 6
                        print(O_status)
                        return False
                    #status
                    O_status = 7
                    return True
    except Exception as argument:
        print(L_func_name,O_status)
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return O_status

#--------------------------------------------------------------
# Function to setup sales hist need
#--------------------------------------------------------------

def setup_sales_hist_need(conn
                          ,I_alloc
                          ,O_status):
    L_func_name ="setup_sales_hist_need"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\calculation_setup_queries.yaml') as fh:
            queries      = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_fetch_rule = queries['setup_sales_hist_need']['Q_fetch_rule']
            
            #status
            O_status = 1

            df_alloc_rule = pd.read_sql(Q_fetch_rule,conn,params=(I_alloc,))
            #status
            O_status = 2

            if len(df_alloc_rule)>0:                
                L_rule_level = df_alloc_rule.rule_level[0]
                #status
                O_status = 3
                #sku level sales hist
                if L_rule_level =='S':
                    #status
                    O_status = 4
                    if setup_sku_sales_hist_need(conn,I_alloc,O_status) == False:
                        #status
                        O_status = 5
                        return False
                    return True
    except Exception as argument:
        print(L_func_name,O_status)
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return False

#--------------------------------------------------------------
# Function to get sku level sales hist
#--------------------------------------------------------------

def setup_sku_sales_hist_need(conn
                              ,I_alloc
                              ,O_status):
    L_func_name ="setup_sku_sales_hist_need"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\calculation_setup_queries.yaml') as fh:
            queries                   = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_fetchall_rule           = queries['setup_sku_sales_hist_need']['Q_fetchall_rule']
            Q_item_loc_hist_loop      = queries['setup_sku_sales_hist_need']['Q_item_loc_hist_loop']
            Q_ecom_item_loc_hist_loop = queries['setup_sku_sales_hist_need']['Q_ecom_item_loc_hist_loop']
            Q_update_sales            = queries['setup_sku_sales_hist_need']['Q_update_sales']
            Q_update_ecom_sales       = queries['setup_sku_sales_hist_need']['Q_update_ecom_sales']
          
            mycursor = conn.cursor()
            #status
            O_status = 1

            #Q_fetchall_rule
            df_alloc_rule = pd.read_sql(Q_fetchall_rule,conn,params=(I_alloc,))
            #status
            O_status = 2

            if len(df_alloc_rule)>0:               
                L_regular_sales_ind   = df_alloc_rule.regular_sales_ind[0]
                L_promo_sales_ind     = df_alloc_rule.promo_sales_ind[0]
                L_clearance_sales_ind = df_alloc_rule.clearance_sales_ind[0]
                L_rule_type           = df_alloc_rule.rule_type[0]
                #L_rule_level          = df_alloc_rule.rule_level[0] #added 
                #status
                O_status = 3
                df_item_loc_hist_loop = pd.read_sql(Q_item_loc_hist_loop,conn,params=(I_alloc,))

                #status
                O_status = 4
                if len(df_item_loc_hist_loop)>0:
                    #status
                    O_status = 5

                    for i in range(len(df_item_loc_hist_loop)):
                        print(len(df_item_loc_hist_loop))
                        L_alloc_no = df_item_loc_hist_loop.loc[i, "alloc_no"]
                        L_eow_date = df_item_loc_hist_loop.loc[i, "eow_date"]
                        L_weight   = df_item_loc_hist_loop.loc[i, "weight"]
                        params     = (L_weight,L_weight,L_regular_sales_ind,L_promo_sales_ind,L_clearance_sales_ind,L_alloc_no,L_eow_date) #L_rule_type parameter is not used
                        params     = convert_numpy(params)
                        #Q_update_sales
                        mycursor.execute(Q_update_sales,params)
                        print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    #commit
                    conn.commit()
                    #status
                    O_status = 6

                #Q_ecom_item_loc_hist_loop
                df_ecom_item_loc_hist_loop = pd.read_sql(Q_ecom_item_loc_hist_loop,conn, params=(I_alloc,))
                #status
                O_status = 7

                if len(df_ecom_item_loc_hist_loop)>0:
                    #status
                    O_status = 8
                    for i in range(len(df_ecom_item_loc_hist_loop)):
                        L_alloc_no            = df_ecom_item_loc_hist_loop.loc[i, "alloc_no"]
                        #L_rule_many_to_one_id = df_ecom_item_loc_hist_loop.loc[i, "rule_many_to_one_id"]
                        L_eow_date            = df_ecom_item_loc_hist_loop.loc[i, "eow_date"]
                        L_weight              = df_ecom_item_loc_hist_loop.loc[i, "weight"]
                        #Q_update_sales
                        params     = (L_weight,L_weight,L_regular_sales_ind,L_promo_sales_ind,L_clearance_sales_ind,L_alloc_no,L_rule_type,L_eow_date)
                        params     = convert_numpy(params)
                        mycursor.execute(Q_update_ecom_sales,params)
                        print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    #commit
                    conn.commit()
                    #status
                    O_status = 9
                return True

    except Exception as argument:
        print(L_func_name,O_status)
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return False

#--------------------------------------------------------------
# Function to finalize sales setup
#--------------------------------------------------------------

def finalize_sale_setup(conn
                        ,I_alloc
                        ,O_status):
    L_func_name ="finalize_sale_setup"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\calculation_setup_queries.yaml') as fh:
            queries               = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_fetch_rule          = queries['finalize_sale_setup']['Q_fetch_rule']
            Q_merge_calc_dest_sku = queries['finalize_sale_setup']['Q_merge_calc_dest_sku']

            mycursor = conn.cursor()
            #status
            O_status = 1
            #Q_fetch_rule
            df_alloc_rule = pd.read_sql(Q_fetch_rule,conn,params=(I_alloc,))
            #status
            O_status = 2
            if len(df_alloc_rule)>0:               
                L_rule_level = df_alloc_rule.rule_level[0]
                #status
                O_status = 3
                if L_rule_level =='S':
                    #status
                    O_status = 4
                    mycursor.execute(Q_merge_calc_dest_sku,(I_alloc,))
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    conn.commit()
                    #status
                    O_status = 5
                    return True

    except Exception as argument:
        print(L_func_name,O_status)
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return False

#--------------------------------------------------------------
# Function to setup calculation
#--------------------------------------------------------------

def calculation_setup(conn
                      ,I_alloc
                      ,O_status):
    L_func_name ="calculation_setup"
    O_status =0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\calculation_setup_queries.yaml') as fh:
            queries      = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_chk_alloc  = queries['calculation_setup']['Q_chk_alloc']
            Q_fetch_rule = queries['calculation_setup']['Q_fetch_rule']
            
            #status
            O_status = 1

            if pop_calc_destination(conn,I_alloc,O_status) == False:
                #status
                O_status = 2
                print("pop_calc_destination: ",O_status)
                return False
            
            #pop_inv_buckets
            if pop_inv_buckets(conn,I_alloc,O_status) == False:
                #status
                O_status = 3
                print("pop_inv_buckets: ",O_status)
                return False
            
            df_alloc_head = pd.read_sql(Q_chk_alloc,conn,params=(I_alloc,))
            #status
            O_status = 4
            if len(df_alloc_head)>0:
                L_alloc_level = df_alloc_head.alloc_level[0]
                #status
                O_status = 5
                if len(L_alloc_level)>0:
                    #status
                    O_status = 5
                    #setup_need
                    if setup_need(conn,I_alloc,O_status) == False:
                        #status
                        O_status = 6
                        print("setup_need: ",O_status)
                        return False

            if finalize_sale_setup(conn,I_alloc,O_status) == False:
                #status
                O_status = 7
                print("finalize_sale_setup: ",O_status)
                return False
    except Exception as argument:
        print(L_func_name,O_status)
        print("Exception occured in: ",L_func_name,argument)        
        conn.rollback()
        return O_status