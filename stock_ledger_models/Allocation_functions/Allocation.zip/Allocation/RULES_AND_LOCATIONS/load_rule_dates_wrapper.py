
from ..RULES_AND_LOCATIONS.change_weight import load_rule_dates_weight
#from ..GLOBAL_FILES.get_connection import get_mysql_conn
from django.db import connection


#----------------------------------------------------------
# Function to call other fuctions fro testing
#----------------------------------------------------------
def fetch_load_rule_dates_wt(connection,I_alloc_no):
    L_func_name="fetch_load_rule_dates_wt"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = load_rule_dates_weight(connection,I_alloc_no,O_status)
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False

#if __name__ == "__main__":
#    I_alloc = '220'
#    L_func_call = fetch_load_rule_dates_wt(I_alloc)    
#    print(L_func_call)