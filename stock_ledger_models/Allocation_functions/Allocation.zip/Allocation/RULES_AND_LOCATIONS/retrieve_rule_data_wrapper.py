from ..GLOBAL_FILES.get_connection import get_mysql_conn
from .retrieve_rule_data import retrieve_rule
from django.db import connection
import pandas as pd

#----------------------------------------------------------
# Function to call other fuctions for testing
#----------------------------------------------------------
def rtv_rule(conn,I_alloc_no):
    L_func_name="test_func"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = retrieve_rule(conn,
                                        I_alloc_no,
                                        O_status)
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        emp =list()
        return emp




#if __name__ == "__main__":
#    I_alloc = '203'
#    L_func_call = rtv_rule(I_alloc)    
#    print(L_func_call)



