from .Connection import get_mysql_conn
#from django.db import connection
from .setup_rules_locations import DELETE_LOCATIONS
import pandas as pd

#----------------------------------------------------------
# Function to call other fuctions for testing
#----------------------------------------------------------
def DEL_LOCS(conn,I_alloc_no):
    L_func_name="test_func"
    #O_status =list()
    emp = list()
    try:
        print("CONNECTION SUCCESS")
        #I_get_mysql_conn = list()
        #I_get_mysql_conn.append(0)
        L_func_call = DELETE_LOCATIONS(conn,I_alloc_no)
        #print(L_func_call)
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        #conn.rollback()
        return emp




#if __name__ == "__main__":
#    I_alloc = '12345678'
#    L_func_call = DEL_LOCS(I_alloc)    
#    print(L_func_call)




