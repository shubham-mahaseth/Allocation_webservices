
from .change_weight import retrieve_rule_dates_weight
from ..GLOBAL_FILES.get_connection import get_mysql_conn
#from django.db import connection


#----------------------------------------------------------
# Function to call other fuctions fro testing
#----------------------------------------------------------
def fetch_retrieve_chng_wt(conn,I_alloc_no):
    L_func_name="fetch_retrieve_chng_wt"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = retrieve_rule_dates_weight(conn,I_alloc_no,O_status)
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return False

if __name__ == "__main__":
    I_alloc = '220'
    L_func_call = fetch_retrieve_chng_wt(I_alloc)    
    print(L_func_call)