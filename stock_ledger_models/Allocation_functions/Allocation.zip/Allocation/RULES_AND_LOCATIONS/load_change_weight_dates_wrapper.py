from .Connection import get_mysql_conn
from ..RULES_AND_LOCATIONS.change_weight import load_change_weight_dates
from django.db import connection


#----------------------------------------------------------
# Function to call other fuctions fro testing
#----------------------------------------------------------
def fetch_chng_wt(connection,I_alloc):
    L_func_name="fetch_chng_wt"
    O_status =list()
    print("load_change_weight_dates:",I_alloc)
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        L_func_call = load_change_weight_dates(connection,I_alloc,O_status)
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False

if __name__ == "__main__":
    I_alloc = '220'
    L_func_call = fetch_chng_wt(I_alloc)    
    print(L_func_call)