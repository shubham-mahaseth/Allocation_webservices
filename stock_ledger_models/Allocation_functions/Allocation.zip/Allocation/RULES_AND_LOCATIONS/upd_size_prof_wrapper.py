from ..GLOBAL_FILES.get_connection import get_mysql_conn
from .setup_rules_locations import UPDATE_SIZE_PROFILE_IND
#from django.db import connection
import pandas as pd

#----------------------------------------------------------
# Function to call other fuctions for testing
#----------------------------------------------------------
def SIZE_PROF(connection,I_alloc_no,I_size_prof_ind):
    L_func_name="test_func"
    try:
        print("CONNECTION SUCCESS")
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = UPDATE_SIZE_PROFILE_IND(connection,I_alloc_no,I_size_prof_ind)
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        connection.rollback()
        return False




#if __name__ == "__main__":
#    I_alloc = '12345678'
#    I_size_prof_ind = 'Y'
#    L_func_call = SIZE_PROF(I_alloc,I_size_prof_ind)    
#    print(L_func_call)




