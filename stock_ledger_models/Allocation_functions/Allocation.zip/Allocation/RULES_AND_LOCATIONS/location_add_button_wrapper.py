#from ..GLOBAL_FILES.get_connection import get_mysql_conn
from .populate_store import populate_store
from django.db import connection



#----------------------------------------------------------
# Function to populate stores for allocation
#----------------------------------------------------------
def pop_store(conn,I_search_criteria):
    L_func_name="pop_store"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        L_func_call = populate_store(conn,
                                        I_search_criteria,
                                        O_status)
        return L_func_call

    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




#if __name__ == "__main__":
#    i_search_criteria = {"ALLOC_NO": '51'
#                          ,"ALL_STORE": 'Y'
#                          ,"LOCATION": []
#                          ,"LOCATION_LIST": []
#                          ,"LOCATION_TRAIT": []
#                          ,"EXCLUDE_LOCATION": []
#                         }

#    l_func_call = pop_store(i_search_criteria)    
#    print(l_func_call)
