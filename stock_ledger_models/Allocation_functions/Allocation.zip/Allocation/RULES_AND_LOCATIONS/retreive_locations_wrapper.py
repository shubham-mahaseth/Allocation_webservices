from ..GLOBAL_FILES.get_connection import get_mysql_conn
from .setup_rules_locations import RETREIVE_LOCATIONS
import pandas as pd
from django.db import connection
#----------------------------------------------------------
# Function to call other fuctions for testing
#----------------------------------------------------------
def RTV_LOCS(conn,I_alloc_no):
    L_func_name="test_func"
    O_status =list()
    try:
        print("CONNECTION SUCCESS")
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = RETREIVE_LOCATIONS(conn,I_alloc_no)           
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        #conn.rollback()
        return O_status




#if __name__ == "__main__":
#    I_alloc = '111222'
#    L_func_call = RTV_LOCS(I_alloc)    
#    print(L_func_call)



