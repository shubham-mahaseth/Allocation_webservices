from ..GLOBAL_FILES.get_connection import get_mysql_conn
from .setup_rules_locations import INSERT_LOCATIONS
#from django.db import connection
import pandas as pd

#----------------------------------------------------------
# Function to call other fuctions for testing
#----------------------------------------------------------
def INS_LOCS(conn,I_alloc_no):
    L_func_name="test_func"
    O_status =list()
    try:
        print("CONNECTION SUCCESS")
        L_func_call = INSERT_LOCATIONS(conn,I_alloc_no)
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




#if __name__ == "__main__":
#    I_alloc = '111222'
#    L_func_call = INS_LOCS(I_alloc)    
#    print(L_func_call)




