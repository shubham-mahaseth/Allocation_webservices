from .Connection import get_mysql_conn
from .setup_rules_locations import UPDATE_STORE_WH_REL
import pandas as pd
from django.db import connection
#----------------------------------------------------------
# Function to call other fuctions for testing
#----------------------------------------------------------
def STORE_WH(connection,I_alloc_no,I_store_wh_rel_ind):
    L_func_name="test_func"
    #O_status =list()
    #emp = list()
    try:
        print("CONNECTION SUCCESS")
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = UPDATE_STORE_WH_REL(connection,I_alloc_no,I_store_wh_rel_ind)
        if L_func_call == False:
            return False
            #print(L_func_call)
        return True
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        connection.rollback()
        return False




#if __name__ == "__main__":
#    I_alloc = '111222'
#    I_store_wh_rel_ind = 'N'
#    L_func_call = STORE_WH(I_alloc,I_store_wh_rel_ind)    
#    print(L_func_call)





