import os
import contextlib
import mysql.connector
from mysql.connector import errorcode
import warnings
import mysqlx
warnings.filterwarnings('ignore')

#------------------------------------------
os.environ['MYSQL_HOST'] = 'localhost'
os.environ['MYSQL_USER'] = 'root'
os.environ['MYSQL_PASSWORD'] = 'Satya@6650'
os.environ['MYSQL_PORT'] = '3306'
os.environ['MYSQL_DB'] = 'allocation'
#------------------------------------------


#----------------------------------------------------------
# Function to Connect to your MYSQL DB
#----------------------------------------------------------
@contextlib.contextmanager
def get_mysql_conn(O_status):
    try:
        #O_status[0]=0
        conn = mysql.connector.connect(host=os.environ.get('MYSQL_HOST'),
                                       user=os.environ.get('MYSQL_USER'),
                                       password=os.environ.get('MYSQL_PASSWORD'),
                                       database=os.environ.get('MYSQL_DB'))
        yield conn
    except mysql.connector.Error as err:
        if err.errno == errorcode.ER_ACCESS_DENIED_ERROR:
            print("Something is wrong with your user name or password")
            O_status[0]=1
            return conn
        elif err.errno == errorcode.ER_BAD_DB_ERROR:
            print("Database does not exist")
            #O_status[0]=1
            return conn
        else:
            print(err)
            O_status[0]=1
            return conn
