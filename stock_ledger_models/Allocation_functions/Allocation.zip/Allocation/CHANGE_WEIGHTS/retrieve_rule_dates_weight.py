from asyncio.windows_events import NULL
from contextlib import nullcontext
from logging import NullHandler
import mysql.connector
from pickle import NONE
from types import NoneType
from ..GLOBAL_FILES.get_connection import get_mysql_conn
import pandas as pd
import yaml

def retrieve_rule_dates_weight(conn,I_alloc_no,O_status):
    L_func_name ="retrieve_rule_dates_weight"
    try: 
        with open(r'D:\MERGED ALLOCATION\Webservices\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\change_weight_queries.yaml') as fh:
            queries           = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_del      = queries['retrieve_rule_dates_weight']['Q_del']
            Q_ins   = queries['retrieve_rule_dates_weight']['Q_ins']
            Q_fetch   = queries['retrieve_rule_dates_weight']['Q_fetch']
            
            O_status=(1)
            mycursor=conn.cursor()
            I_get_mysql_conn = list()
            I_get_mysql_conn.append(0)
            
            O_status=(2)
            mycursor.execute(Q_del,(I_alloc_no,))
            print(O_status,"-","rows_affected: ",mycursor.rowcount)
            
            O_status=(3)           
            mycursor.execute(Q_ins,(I_alloc_no,))
            print(O_status,"-","rows_affected: ",mycursor.rowcount)

            conn.commit()
            df_fetch=pd.read_sql(Q_fetch,conn,params=(I_alloc_no,))
            print(df_fetch)
            return df_fetch
    except mysql.connector.Error as error:
        if O_status==(1):
            print(L_func_name,":",O_status,":","Exception occured while execute the CONN: ", error)
        elif O_status==(2):
             print(L_func_name,":",O_status,":","Exception occured while fetching the Q_del: ", error)
        elif O_status==(3):
             print(L_func_name,":",O_status,":","Exception occured while fetching the Q_ins: ", error)
        else:
            print("Exception occured in: ",L_func_name.format(error))
        conn.rollback()
        return False
