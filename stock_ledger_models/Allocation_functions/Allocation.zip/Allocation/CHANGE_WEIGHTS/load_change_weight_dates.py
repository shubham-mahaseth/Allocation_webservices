#from .Connection import get_mysql_conn
from ..GLOBAL_FILES.get_connection import get_mysql_conn
from datetime import date, timedelta,datetime
import pandas as pd
import numpy as np
import math as mt
import yaml
import mysql



def seed_ly_eow (conn
                ,I_dd
                ,I_mm
                ,I_yyyy              
                ,O_status):
    L_func_name ="seed_ly_eow"
    O_status = [0]
    emp_list = list()
    try:        
        with open(r'D:\MERGED ALLOCATION\Webservices\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\change_weight_queries.yaml') as fh:
            queries       = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_align_input = queries['seed_ly_eow']['Q_align_input']
            Q_seed_eow    = queries['seed_ly_eow']['Q_seed_eow']
            Q_out_wk_454  = queries['seed_ly_eow']['Q_out_wk_454']
            Q_out_dd_454  = queries['seed_ly_eow']['Q_out_dd_454']

            mycursor = conn.cursor()
            #status
            O_status=(1)

            df_input = pd.read_sql(Q_align_input,conn,params=(I_yyyy,I_mm,I_dd))
            L_cal_date1 = df_input.cal_date[0]
            L_cal_date = datetime.strptime(L_cal_date1, '%Y-%m-%d').date()

            #status
            O_status=(2)

            #Q_seed_eow
            df_seed_eow = pd.read_sql(Q_seed_eow,conn,params=(L_cal_date,L_cal_date))
            L_days = df_seed_eow.dd[0]
            O_mm   = df_seed_eow.mm[0]
            O_yyyy = df_seed_eow.yyyy[0]

            #status
            O_status=(3)
            np_int = np.int64(L_days)
            L_days = np_int.item()
            #Q_out_wk_454
            df_wk_454 = pd.read_sql(Q_out_wk_454,conn,params=(L_days,))
            O_wk = df_wk_454.wk_454[0]
            np_int = np.int64(O_wk)
            O_wk = np_int.item()
            if O_wk>5:
                #status
                O_status=("NO_DATA_FOUND")
                return emp_list #False

            #status
            O_status=(4)

            #Q_out_dd_454
            df_dd_454 = pd.read_sql(Q_out_dd_454,conn,params=(L_days,O_wk))
            O_dd = df_dd_454.dd_454[0]

            

            O_date_list =list()
            O_date_list.append(O_dd)
            O_date_list.append(O_mm)
            O_date_list.append(O_yyyy)
            O_date_list.append(O_wk)

            return O_date_list

    except mysql.connector.Error as error:
        if O_status==(1):
            print(L_func_name,":",O_status,":","Exception occured while fetching the Q_align_input: ", error)
        elif O_status==(2):
             print(L_func_name,":",O_status,":","Exception occured while fetching the Q_seed_eow: ", error)
        elif O_status==(3):
             print(L_func_name,":",O_status,":","Exception occured while fetching the Q_out_wk_454: ", error)
        elif O_status==(4):
             print(L_func_name,":",O_status,":","Exception occured while fetching the Q_out_dd_454: ", error)
        else:
            print("Exception occured in: ",L_func_name.format(error))
        conn.rollback()
        return False

#--------------------------------------------------------------
# Function to fetch eow (C454_TO_CAL)
#--------------------------------------------------------------
def fetch_ly_eow (conn
                ,I_dd
                ,I_mm
                ,I_yyyy
                ,I_wk
                ,O_status):
    L_func_name ="seed_ly_eow"
    emp_list = list()
    O_status = [0]

    try:
        with open(r'D:\MERGED ALLOCATION\Webservices\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\change_weight_queries.yaml') as fh:
            queries         = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_date_add      = queries['fetch_ly_eow']['Q_date_add']
            Q_fetch_eow     = queries['fetch_ly_eow']['Q_fetch_eow']
            Q_format_output = queries['fetch_ly_eow']['Q_format_output']
            
            O_status=(1)
            df_date_add = pd.read_sql(Q_date_add,conn,params=(I_wk,I_dd))
            L_date_add  = df_date_add.date_add[0]
   
            np_int = np.float64(L_date_add)
            L_date_add = np_int.item()
            np_int = np.float64(I_yyyy)
            I_yyyy = np_int.item()
            np_int = np.int64(I_mm)
            I_mm = np_int.item()            

            #Q_fetch_eow
            O_status=(2)
            df_fetch_eow = pd.read_sql(Q_fetch_eow,conn,params=(L_date_add,I_yyyy,I_mm))

            L_cal_date    = df_fetch_eow.cal_date[0]
            L_no_of_weeks = df_fetch_eow.no_of_weeks[0]
            
            O_status=(3)
            #Q_format_output
            print(Q_format_output)
            df_format_output = pd.read_sql(Q_format_output,conn,params=(L_cal_date,L_cal_date,L_cal_date))
            O_dd   = df_format_output.dd[0]
            O_mm   = df_format_output.mm[0]
            O_yyyy = df_format_output.yyyy[0]

            if L_no_of_weeks<I_wk:
                return emp_list #false
            O_date_list =list()
            O_date_list.append(O_dd)
            O_date_list.append(O_mm)
            O_date_list.append(O_yyyy)

            return O_date_list

    except mysql.connector.Error as error:
        if O_status==(1):
            print(L_func_name,":",O_status,":","Exception occured while fetching the Q_date_add: ", error)
        elif O_status==(2):
             print(L_func_name,":",O_status,":","Exception occured while fetching the Q_fetch_eow: ", error)
        elif O_status==(3):
             print(L_func_name,":",O_status,":","Exception occured while fetching the Q_format_output: ", error)
        else:
            print("Exception occured in: ",L_func_name.format(error))
        conn.rollback()
        return False
   
#--------------------------------------------------------------
# Function to populate eow (CAL_TO_454_LDOW)
#--------------------------------------------------------------
def pop_ly_eow (conn
                ,I_dd
                ,I_mm
                ,I_yyyy
                ,O_status):
    L_func_name ="pop_ly_eow"
    O_status = [0]
    emp_list = list()

    try:
        F_seed_ly_eow = seed_ly_eow(conn,I_dd,I_mm,I_yyyy,O_status)
        O_status=(1)
        if len(F_seed_ly_eow)>0:
            L_day = 7
            L_month = F_seed_ly_eow[1]
            L_year = F_seed_ly_eow[2]
            L_week = F_seed_ly_eow[3]

            O_status=(2)
            F_fetch_ly_eow = fetch_ly_eow(conn,L_day,L_month,L_year,L_week,O_status)
            if len(F_fetch_ly_eow)>0:
                return F_fetch_ly_eow
            else:
                return emp_list

    except mysql.connector.Error as error:
        if O_status==(1):
            print(L_func_name,":",O_status,":","Exception occured while calling the seed_ly_eow: ", error)
        elif O_status==(2):
             print(L_func_name,":",O_status,":","Exception occured while calling the seed_ly_eow: ", error)
        else:
            print("Exception occured in: ",L_func_name.format(error))
        conn.rollback()
        return False
  
#--------------------------------------------------------------
# Function to setup change weight
#--------------------------------------------------------------
def load_change_weight_date (conn
                              ,I_alloc
                              ,O_status):
    L_func_name ="load_change_weight_date"
    O_status = [0]

    try:
         with open(r'D:\MERGED ALLOCATION\Webservices\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\change_weight_queries.yaml') as fh:
            queries           = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_fetch_rule      = queries['change_weight']['Q_fetch_rule']
            Q_del_rule_date   = queries['change_weight']['Q_del_rule_date']
            Q_ins_rule_date   = queries['change_weight']['Q_ins_rule_date']
            Q_date_loop_range = queries['change_weight']['Q_date_loop_range']
            Q_fetch_ty_eow    = queries['change_weight']['Q_fetch_ty_eow']
            Q_chk_ly_ty_ind   = queries['change_weight']['Q_chk_ly_ty_ind']
            Q_fetch_cur_date  = queries['change_weight']['Q_fetch_cur_date']
            Q_format_output   = queries['change_weight']['Q_format_output']
            Q_ly_eow          = queries['change_weight']['Q_ly_eow']
            mycursor = conn.cursor()
            #status
            O_status=(1)

            df_fetch_rule     = pd.read_sql(Q_fetch_rule,conn,params=(I_alloc,))
            L_weeks_this_year = df_fetch_rule.weeks_this_year[0]
            L_weeks_last_year = df_fetch_rule.weeks_last_year[0]
            L_start_date1     = df_fetch_rule.start_date1[0]
            L_start_date2     = df_fetch_rule.start_date2[0]
            L_end_date1       = df_fetch_rule.end_date1[0]
            L_end_date2       = df_fetch_rule.end_date2[0]
            L_rule_type       = df_fetch_rule.rule_type[0]

            #status
            O_status=(2)

            #Q_del_rule_date
            mycursor.execute(Q_del_rule_date,(I_alloc,))
            print(O_status,"-","rows_affected: ",mycursor.rowcount)

            #status
            O_status=(3)

            L_eow_dates = list()

            if L_start_date1 !=None or L_start_date2 != None:
                #status
                O_status=(4)
                df_date_loop = pd.read_sql(Q_date_loop_range,conn,params=(I_alloc,))
                L_date1 = df_date_loop.date1[0]
                L_date2 = df_date_loop.date2[0]
                L_date1 = mt.trunc(L_date1)
                L_date2 = mt.trunc(L_date2)

                #status
                O_status=(5)
                if L_date1 != -1:
                    #status
                    O_status=(L_date1)
                    L_start_loop = L_start_date1 - timedelta(7)
                   
                   
                    for i in range(L_date1):
                        L_start_loop = L_start_loop + timedelta(7)
                        L_eow_dates.append(L_start_loop)
                       
                if L_date2 != -1:
                    print("qqqqq",L_date2)
                    #status
                    O_status=(6)
                    L_start_loop = L_start_date2 - timedelta(7)
                   
                    for i in range(L_date2):
                        L_start_loop = L_start_loop + timedelta(7)
                        L_eow_dates.append(L_start_loop)

            if L_weeks_this_year != None:
                L_weeks_this_year = mt.trunc(L_weeks_this_year)

                #status
                O_status=(7)

                df_ty_eow = pd.read_sql(Q_fetch_ty_eow,conn)
                L_ty_eow = df_ty_eow.last_eow_date[0]

                #status
                O_status=(8)

                if L_rule_type =='H':
                    L_start_loop = L_ty_eow + timedelta(7)
                    for i in range(L_weeks_this_year):
                        L_start_loop = L_start_loop - timedelta(7)
                        L_eow_dates.append(L_start_loop)
                else:
                    L_start_loop = L_ty_eow - timedelta(7)
                    for i in range(L_weeks_this_year):
                        L_start_loop = L_start_loop + timedelta(7)
                        L_eow_dates.append(L_start_loop)
   
            #Q_chk_ly_ty_ind
            df_ly_ty_ind = pd.read_sql(Q_chk_ly_ty_ind,conn,params=(I_alloc,))
            L_df_ly_ty_ind = df_ly_ty_ind.ty_ly_ind[0]

            #ty
            if L_weeks_last_year != None:
                L_weeks_last_year = mt.trunc(L_weeks_last_year)

                #status
                O_status=(9)
                #Q_fetch_cur_date
                df_cur_date = pd.read_sql(Q_fetch_cur_date,conn)
                L_last_year_date = df_cur_date.last_year[0]

                #Q_format_output
                df_format_output = pd.read_sql(Q_format_output,conn,params=(L_last_year_date,L_last_year_date,L_last_year_date))
                I_dd   = df_format_output.dd[0]
                I_mm   = df_format_output.mm[0]
                I_yyyy = df_format_output.yyyy[0]

                #status
                O_status=(10)

                F_pop_ly_eow = pop_ly_eow (conn,I_dd,I_mm,I_yyyy,O_status)
                if len(F_pop_ly_eow)==0:
                    #status
                    O_status=("pop_ly_eow")
                    print(O_status)
                    conn.rollback()
                    return False

                O_yyyy = F_pop_ly_eow[2]
                O_mm   = F_pop_ly_eow[1]
                O_dd   = F_pop_ly_eow[0]

                #Q_ly_eow
                df_ly_eow = pd.read_sql(Q_ly_eow,conn,params=(O_yyyy,O_mm,O_dd))
                L_ly_eow = df_ly_eow.ly_eow[0]
                L_ly_eow = datetime.strptime(L_ly_eow, '%Y-%m-%d').date()

                if L_rule_type =='H':
                    L_start_loop = L_ly_eow + timedelta(7)
                    for i in range(L_weeks_last_year):
                        L_start_loop = L_start_loop - timedelta(7)
                        L_eow_dates.append(L_start_loop)
                else:
                    L_start_loop = L_ly_eow - timedelta(7)
                    for i in range(L_weeks_last_year):
                        L_start_loop = L_start_loop + timedelta(7)
                        L_eow_dates.append(L_start_loop)

            #getting unique values
            L_eow_dates= np.unique(L_eow_dates)

            #status
            O_status=(11)
            for i in range(len(L_eow_dates)):
                mycursor.execute(Q_ins_rule_date,(I_alloc,L_eow_dates[i],L_df_ly_ty_ind,None,1))
                print(O_status,"-","rows_affected: ",mycursor.rowcount)

            #status
            O_status=(12)

            if len(L_eow_dates)>0:
                if pop_need_dates(conn
                                 ,I_alloc
                                 ,O_status)==False:
                    conn.rollback()
                    return False

            conn.commit()
            return True
    except mysql.connector.Error as error:
        if O_status==(1):
            print(L_func_name,":",O_status,":","Exception occured while processing fetching the data: ", error)
        elif O_status==(2) and O_status==(3):
            print(L_func_name,":",O_status,":","Exception occured while processing Q_del_rule_date: ", error)
        elif O_status>=(3) and  O_status<=(6):
            print(L_func_name,":",O_status,":","Exception occured while processing Q_date_loop_range: ", error)        
        elif O_status==(7):
            print(L_func_name,":",O_status,":","Exception occured while processing Q_fetch_ty_eow: ", error)
        elif O_status==(8):
            print(L_func_name,":",O_status,":","Exception occured while processing Q_chk_ly_ty_ind: ", error)
        elif O_status==(9):
            print(L_func_name,":",O_status,":","Exception occured while processing Q_fetch_cur_date: ", error)
        elif O_status==(10):
            print(L_func_name,":",O_status,":","Exception occured while calling the function pop_ly_eow: ", error)
        elif O_status==(11):
            print(L_func_name,":",O_status,":","Exception occured while processing Q_ins_rule_date: ", error)
        elif O_status==(12):
            print(L_func_name,":",O_status,":","Exception occured while calling the pop_need_dates: ", error)
        else:
            print("Exception occured in: ",L_func_name.format(error))
        conn.rollback()
        return False
  

def pop_need_dates(conn,I_alloc,O_status):
    L_func_name ="pop_need_dates"
    O_status = [0]
    try:     
        with open(r'D:\MERGED ALLOCATION\Webservices\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\change_weight_queries.yaml') as fh:
            queries           = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_del_calc_date      = queries['pop_need_dates']['Q_del_calc_date']
            Q_ins_need_date   = queries['pop_need_dates']['Q_ins_need_date']
            
            mycursor = conn.cursor()
            O_status=(1)
            mycursor.execute(Q_del_calc_date,(I_alloc,))
            print(O_status,"-","rows_affected: ",mycursor.rowcount)
            #Q_ins_need_date
            O_status=(2)
            mycursor.execute(Q_ins_need_date,(I_alloc,))
            print(O_status,"-","rows_affected: ",mycursor.rowcount)
            conn.commit()
            return True
 

    except mysql.connector.Error as error:
        if O_status==(1):
            print(L_func_name,":",O_status,":","Exception occured while execute the Q_del_calc_date: ", error)
        elif O_status==(2):
             print(L_func_name,":",O_status,":","Exception occured while execute the Q_ins_need_date: ", error)
        else:
            print("Exception occured in: ",L_func_name.format(error))
        conn.rollback()
        return False
    