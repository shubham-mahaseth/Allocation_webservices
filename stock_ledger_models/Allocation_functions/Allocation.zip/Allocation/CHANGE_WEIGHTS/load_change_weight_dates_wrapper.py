#from .Connection import get_mysql_conn
from .load_change_weight_dates import load_change_weight_date
#from load_rule_dates_weight import load_rule_dates_weight
#from retrieve_rule_dates_weight import retrieve_rule_dates_weight
#from PY_FUN import P360_SKU_AVAIL_QTY
import pandas as pd
from ..GLOBAL_FILES.get_connection import get_mysql_conn


#----------------------------------------------------------
# Function to call other fuctions fro testing
#----------------------------------------------------------
def fetch_chng_wt(conn,I_alloc):
    L_func_name="fetch_chng_wt"
    O_status =list()
    try:
        #I_get_mysql_conn = list()
        #I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = load_change_weight_date(conn,I_alloc,O_status)
        print("fetch_chng_wt2345::",I_alloc,O_status)
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return False

#if __name__ == "__main__":
#    I_alloc = '220'
#    L_func_call = fetch_chng_wt(I_alloc)    
#    print(L_func_call)