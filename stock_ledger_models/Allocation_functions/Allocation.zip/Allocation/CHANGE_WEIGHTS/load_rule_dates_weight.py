from asyncio.windows_events import NULL
from contextlib import nullcontext
from logging import NullHandler
import mysql.connector
from pickle import NONE
from types import NoneType
#from .Connection import get_mysql_conn

from ..GLOBAL_FILES.get_connection import get_mysql_conn
from .load_change_weight_dates import pop_need_dates
import pandas as pd
import yaml

def load_rule_dates_weight(conn,I_alloc_no,O_status):
	L_func_name ="load_rule_dates_weight"
	try:
		with open(r'D:\MERGED ALLOCATION\Webservices\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\change_weight_queries.yaml') as fh:
			queries         = yaml.load(fh, Loader=yaml.SafeLoader)
			L_merge_1      = queries['load_rule_dates_weight']['L_merge_1']
			C_get_rule_rec     = queries['load_rule_dates_weight']['C_get_rule_rec']
			mycursor=conn.cursor()
			O_status=(1)
			mycursor.execute(L_merge_1,(I_alloc_no,))
			conn.commit()
			O_status=(2)
			if 1 != 0:
				L_changes_found = 1
			if L_changes_found == 1:
				mycursor.execute(C_get_rule_rec,(I_alloc_no,))
				O_status=(2)
				L_var=mycursor.fetchall()
				if L_var!=None:
					O_status = list()
					if pop_need_dates(conn
			                          ,I_alloc_no
			                          ,O_status)==False:
						conn.rollback()
						return False
			return True
	
	except mysql.connector.Error as error:
		if O_status==(1):
			print(L_func_name,":",O_status,":","Exception occured while fecthing  the CONN: ", error)
		elif O_status==(2):
			print(L_func_name,":",O_status,":","Exception occured while fetching the Q_del: ", error)
		elif O_status==(3):
			print(L_func_name,":",O_status,":","Exception occured while fetching the Q_ins: ", error)
		else:
			print("Exception occured in: ",L_func_name.format(error))
		conn.rollback()
		return False

