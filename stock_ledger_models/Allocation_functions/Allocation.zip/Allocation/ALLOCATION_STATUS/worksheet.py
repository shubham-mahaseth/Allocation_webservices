import mysql.connector
import pandas as pd
import yaml
from ..GLOBAL_FILES.get_connection import get_mysql_conn


def worksheet(conn,O_status,I_alloc_no):  
    L_func_name = "upd_prgm_audit_entry"
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\worksheet_queries.yaml') as fh:
            queries         = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_sel_status   = queries['worksheet']['Q_sel_status']
            Q_upd_ind   = queries['worksheet']['Q_upd_ind']

            print("conn info:",conn)
            mycursor=conn.cursor()
            O_status = 1
            df_get_allocno_status = pd.read_sql(Q_sel_status,conn,params=(I_alloc_no,))
            L_alloc_status=df_get_allocno_status["status"][0]
            print("L_alloc_status:",L_alloc_status)

            O_status = 2
            if L_alloc_status in ('APV','CNL','RSV'):
                mycursor.execute(Q_upd_ind,(I_alloc_no,))
                print(O_status,"-","rows_affected: ",mycursor.rowcount)
                if mycursor.rowcount > 0:
                    conn.commit()
                    return True
                else:
                    print("Allocation is not in approved,cancel or reserve status.")
                    return False
            else:
                print("alloc status is incorrect.")
                return False
        

    except Exception as error:
        if O_status == 1:
            print(L_func_name,":",O_status,":","Exception occured while selecting the status from alloc_head table: ", error)
        elif O_status == 2:
            print(L_func_name,":",O_status,":","Exception occured while updating status,recalc_ind in alloc_head table: ", error)
        else:
            print(L_func_name,":",O_status,":","Exception occured: ", error)
        conn.rollback()
        return False




#if __name__ == "__main__":
#    I_alloc_no=103
#    O_status=None
#    conn=None
#    daily_view = worksheet(conn,O_status,I_alloc_no)  
#    print(daily_view);





