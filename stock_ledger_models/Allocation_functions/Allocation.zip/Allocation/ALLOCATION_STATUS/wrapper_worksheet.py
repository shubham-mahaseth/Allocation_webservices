import mysql.connector
from ..GLOBAL_FILES.get_connection import get_mysql_conn
from ..ALLOCATION_STATUS.worksheet import worksheet


def worksheet_wrapper(I_alloc_no):
    L_func_name="worksheet_wrapper"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        with get_mysql_conn (I_get_mysql_conn) as conn:
            mycursor=conn.cursor()
            mycursor.execute("SET sql_mode = ''; ")
            L_update_alloc_dtl = worksheet(conn,O_status,I_alloc_no)
            if L_update_alloc_dtl==True:
                return True
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False


if __name__ == "__main__":
    I_alloc_no=334
    daily_view = worksheet_wrapper(I_alloc_no) 
    print(daily_view);

