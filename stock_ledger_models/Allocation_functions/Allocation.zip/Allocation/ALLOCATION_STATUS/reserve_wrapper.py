import mysql.connector
from ..GLOBAL_FILES.get_connection import get_mysql_conn
from ..ALLOCATION_STATUS.reserve import reserve


def reserve_wrapper(I_alloc_no):
    L_func_name="reserve_wrapper"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        with get_mysql_conn (I_get_mysql_conn) as conn:
            mycursor=conn.cursor()
            mycursor.execute("SET sql_mode = ''; ")
            L_update_alloc_dtl = reserve(conn,O_status,I_alloc_no)
            #print("L_update_alloc_dtl: ",L_update_alloc_dtl)
            if L_update_alloc_dtl==True:
                return True
            else:
                return L_update_alloc_dtl[0]

    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False


if __name__ == "__main__":
    I_alloc_no=332
    daily_view = reserve_wrapper(I_alloc_no) 
    print(daily_view);



