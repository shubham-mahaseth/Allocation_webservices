from asyncio.windows_events import NULL
from contextlib import nullcontext
from logging import NullHandler
import mysql.connector
from pickle import NONE
from types import NoneType
from ..GLOBAL_FILES.get_connection import get_mysql_conn
from ..INVENTORY_SETUP.load_item_source import load_item
import yaml

def wrapper_load_source(conn,L_alloc_no,O_status):
    L_func_name="wrapper_load_source"
    O_status =list()
    try:

        #I_get_mysql_conn = list()
        #I_get_mysql_conn.append(0)
        ##print(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_insert_alloc_dtl = load_item(conn,L_alloc_no,O_status)
        return L_insert_alloc_dtl
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False

    
#if __name__ == "__main__":
#    L_alloc = '8'
#    O_status = None
#    L_insert_alloc_dtl = wrapper_load_source(L_alloc,O_status)    
#    print(L_insert_alloc_dtl)

