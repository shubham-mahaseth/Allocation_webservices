from .setup_like_item import delete_like_item_map
#from ..GLOBAL_FILES.get_connection import get_mysql_conn
#from django.db import connection

#----------------------------------------------------------
# Function to delete mapped items for allocation
#----------------------------------------------------------
def delete_mapped_item(connection,I_alloc):

    L_func_name="delete_mapped_item"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = delete_like_item_map(connection
                                            ,I_alloc
                                            ,O_status)
        return L_func_call

    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False









