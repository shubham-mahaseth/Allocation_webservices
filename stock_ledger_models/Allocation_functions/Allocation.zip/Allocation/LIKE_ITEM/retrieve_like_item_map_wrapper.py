#from ..GLOBAL_FILES.get_connection import get_mysql_conn
from .setup_like_item import RETREIVE_LIKE_ITEM_MAP
import pandas as pd
#from django.db import connection
#----------------------------------------------------------
# Function to call other fuctions for testing
#----------------------------------------------------------
def rtv_like_item(connection,I_alloc_no): #conn has to be passed when merging with REACT.
    L_func_name="test_func"
    O_status =list()
    try:
        print("CONNECTION SUCCESS",I_alloc_no)
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn: #with clause has to be removed when merging with REACT.
        L_func_call = RETREIVE_LIKE_ITEM_MAP(connection,I_alloc_no)
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




#if __name__ == "__main__":
#    I_alloc = '335'
#    mode = 'NEW'
#    L_func_call = rtv_like_item(I_alloc)    
#    print(L_func_call)
