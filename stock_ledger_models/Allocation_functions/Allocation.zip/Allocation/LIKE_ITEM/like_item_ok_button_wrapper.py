#from GLOBAL_FILES.get_connection import get_mysql_conn
from .setup_like_item import insert_like_item_map
#from django.db import connection


#----------------------------------------------------------
# Function to insert mapped items for allocation into DB
#----------------------------------------------------------
def insert_mapped_item(connection,I_alloc):

    L_func_name="insert_mapped_item"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = insert_like_item_map(connection
                                            ,I_alloc
                                            ,O_status)
        return L_func_call

    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




if __name__ == "__main__":
    I_alloc = 7

    L_func_call = insert_mapped_item(I_alloc)
    print(L_func_call)



