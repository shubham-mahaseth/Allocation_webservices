from .setup_like_item import map_like_item_details
#from ..GLOBAL_FILES.get_connection import get_mysql_conn
#from django.db import connection


#----------------------------------------------------------
# Function to populate mapped items for allocation
#----------------------------------------------------------
def map_item(connection,I_alloc
             ,I_item_list
             ,I_item_parent         #for style diff
             ,I_sku                 
             ,I_diff_id             #for style diff
             ,I_no_sizes            
             ,I_weight              
             ,I_size_prf_ind        #for style diff
             ):

    L_func_name="map_item"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = map_like_item_details(connection
                                            ,I_alloc
                                            ,I_item_list
                                            ,I_item_parent         #for style diff
                                            ,I_sku                 
                                            ,I_diff_id             #for style diff
                                            ,I_no_sizes            
                                            ,I_weight              
                                            ,I_size_prf_ind        #for style diff
                                            ,O_status)
        return L_func_call

    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




#if __name__ == "__main__":
#    I_alloc = 7
#    I_item_list = None
#    I_item_parent = None        
#    I_sku = 124483809                
#    I_diff_id = None
#    I_no_sizes = 1
#    I_weight = 1
#    I_size_prf_ind = 'N'

#    L_func_call = map_item(I_alloc
#                           ,I_item_list
#                           ,I_item_parent        
#                           ,I_sku                
#                           ,I_diff_id            
#                           ,I_no_sizes           
#                           ,I_weight             
#                           ,I_size_prf_ind)
#    print(L_func_call)


