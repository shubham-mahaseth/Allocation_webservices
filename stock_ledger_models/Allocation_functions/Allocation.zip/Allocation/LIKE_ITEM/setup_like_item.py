from os import O_SEQUENTIAL
from ..GLOBAL_FILES.convert_numpy_64 import convert_numpy
from ..INVENTORY_SETUP.update_alloc_ext import update_alloc
from ..INVENTORY_SETUP.inventory_setup import setup_location
from ..GLOBAL_FILES.null_handler import null_py
from datetime import datetime
import pandas as pd
import numpy as np
import yaml

#############################################################
# Created By - Priyanshu Pandey                             #                
# File Name - calculate.py                                  #
# Purpose - calculate allocation                            #
#############################################################

#--------------------------------------------------------------
# Function to map like items 
#--------------------------------------------------------------

def map_like_item_details(conn
                          ,I_alloc
                          ,I_item_list
                          ,I_item_parent         #for style diff
                          ,I_sku                 
                          ,I_diff_id             #for style diff
                          ,I_no_sizes            #for style diff
                          ,I_weight              
                          ,I_size_prf_ind        #for style diff
                          ,O_status):
    L_func_name ="map_like_item_details"
    print(I_alloc,I_item_list,I_sku)
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\like_item_queries.yaml') as fh:
            queries                      = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_chk_alloc                  = queries['map_like_item_details']['Q_chk_alloc']
            Q_ins_diff_map_item_list_sku = queries['map_like_item_details']['Q_ins_diff_map_item_list_sku']
            Q_ins_diff_map_item_sku      = queries['map_like_item_details']['Q_ins_diff_map_item_sku']
            Q_del_diff_map_item_sku      = queries['map_like_item_details']['Q_del_diff_map_item_sku']
            Q_sku_map_ins_loop           = queries['map_like_item_details']['Q_sku_map_ins_loop']
            Q_del_map_itm_list           = queries['map_like_item_details']['Q_del_map_itm_list']
            Q_fetch_item_diff_temp       = queries['map_like_item_details']['Q_fetch_item_diff_temp']
            Q_fetch_item_diff_map_temp   = queries['map_like_item_details']['Q_fetch_item_diff_map_temp']
            Q_validate_item              = queries['map_like_item_details']['Q_validate_item']

            #status
            O_status = 1 
            mycursor = conn.cursor()

            df_chk_alloc = pd.read_sql(Q_chk_alloc,conn,params=(I_alloc,))

            if df_chk_alloc.alloc_level[0] =='T':
                #status
                O_status = 2

                df_item_loop = pd.read_sql(Q_sku_map_ins_loop,conn,params=(I_alloc,))
                #print(df_item_loop)

                if I_sku != None:
                    O_status = 3
                    if len(df_item_loop)>0:
                        #status
                        O_status = 4
                        for i in range(len(df_item_loop)):
                            L_item = df_item_loop.loc[i,"ITEM"]
                            #Q_validate_item
                            df_val_item = pd.read_sql(Q_validate_item,conn,params=(I_sku,L_item))
                            if len(df_val_item)>0:
                                print("invalid mapping item")
                                return False

                            mycursor.execute(Q_ins_diff_map_item_sku,(I_weight,I_alloc,L_item,I_sku))
                            L_count = mycursor.rowcount
                            print(L_func_name,"-",O_status,"-","rows_affected: ",L_count)

                            #status
                            O_status = 5
                            if L_count>0:
                                mycursor.execute(Q_del_diff_map_item_sku,(I_alloc,L_item))
                                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                if I_item_list !=None:
                    #status
                    O_status = 6
                    mycursor.execute(Q_ins_diff_map_item_list_sku,(I_weight,I_alloc,I_item_list))
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                    #status
                    O_status = 7
                    #Q_del_map_itm_list
                    for i in range(len(df_item_loop)):
                        L_item = df_item_loop.loc[i,"ITEM"]
                        mycursor.execute(Q_del_map_itm_list,(I_alloc,L_item,I_alloc))
                        print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
            #status
            O_status = 8
            conn.commit()
            df_item_diff_temp     = pd.read_sql(Q_fetch_item_diff_temp,conn,params=(I_alloc,))
            df_item_diff_map_temp = pd.read_sql(Q_fetch_item_diff_map_temp,conn,params=(I_alloc,))

            conn.commit()
            return df_item_diff_temp,df_item_diff_map_temp

    except Exception as error:
        if O_status==1:
            print(L_func_name,":",O_status,":","Exception occured while creating table: ", error)
        elif O_status>=2 or O_status <=4:
            print(L_func_name,":",O_status,":","Exception occured while inserting alloc_like_item_diff_map_temp for sku: ", error)
        elif O_status==5:
            print(L_func_name,":",O_status,":","Exception occured while deleting alloc_like_item_diff_temp for sku: ", error)
        elif O_status==6:
            print(L_func_name,":",O_status,":","Exception occured while inserting alloc_like_item_diff_map_temp for skulist: ", error)
        elif O_status==7:
            print(L_func_name,":",O_status,":","Exception occured while deleting alloc_like_item_diff_temp for sku: ", error)
        elif O_status==8:
            print(L_func_name,":",O_status,":","Exception occured while processing dataframe for output: ", error)
        else:
            print(L_func_name,":",O_status,"Exception occured in: ",L_func_name,error)
        conn.rollback()
        return False

#--------------------------------------------------------------
# Function to insert mapped like items into DB
#--------------------------------------------------------------

def insert_like_item_map(conn
                         ,I_alloc
                         ,O_status):
    L_func_name ="insert_like_item_map"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\like_item_queries.yaml') as fh:
            queries             = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_chk_alloc         = queries['insert_like_item_map']['Q_chk_alloc']
            Q_merge_calc_source = queries['insert_like_item_map']['Q_merge_calc_source']
            Q_upd_calc_source   = queries['insert_like_item_map']['Q_upd_calc_source']
            Q_upd_src_ext       = queries['insert_like_item_map']['Q_upd_src_ext']
            Q_del_src_ext       = queries['insert_like_item_map']['Q_del_src_ext']
            Q_ins_src_ext       = queries['insert_like_item_map']['Q_ins_src_ext']
            #Q_chk_dest_range    = queries['insert_like_item_map']['Q_chk_dest_range']
            Q_chk_alloc_rule    = queries['insert_like_item_map']['Q_chk_alloc_rule']

            mycursor = conn.cursor()
            L_row_cnt = 0
            #status
            O_status = 2
            df_chk_alloc = pd.read_sql(Q_chk_alloc,conn,params=(I_alloc,))

            if df_chk_alloc.alloc_level[0] =='T':
                #status
                O_status = 3

                #Q_merge_calc_source
                mycursor.execute(Q_merge_calc_source,(I_alloc,))
                L_row_cnt = mycursor.rowcount
                print(L_func_name,"-",O_status,"-","rows_affected: ",L_row_cnt)
                if L_row_cnt>0:
                    L_row_cnt =1

            #status
            O_status = 4
            #Q_upd_calc_source
            mycursor.execute(Q_upd_calc_source,(I_alloc,))
            print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

            #status
            O_status = 5
            #Q_upd_src_ext
            mycursor.execute(Q_upd_src_ext,(I_alloc,))
            print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

            if L_row_cnt ==1:
                #status
                O_status = 6
                #Q_del_src_ext
                mycursor.execute(Q_del_src_ext,(I_alloc,))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                #status
                O_status = 7
                #Q_ins_src_ext
                mycursor.execute(Q_ins_src_ext,(I_alloc,))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                I_input_data = list()
                if update_alloc(conn,
                                O_status,
                                I_alloc,
                                None,
                                None,
                                'Y',
                                I_input_data) ==False:
                    #status
                    O_status=8
                    print(O_status,"- update_alloc failed")
                    conn.rollback()
                    return False
                #status
                O_status = 9
                ##Q_chk_dest_range
                #df_dest_ranged = pd.read_sql(Q_chk_dest_range,conn,params=(I_alloc,))

                #if df_dest_ranged.chk[0] == 1:
                #status
                O_status = 10
                #Q_chk_dest_range
                df_chk_rule = pd.read_sql(Q_chk_alloc_rule,conn,params=(I_alloc,))

                if len(df_chk_rule)>0:
                    #status
                    O_status=11
                    if setup_location(conn
                                        ,I_alloc
                                        ,O_status) ==False:
                        #status
                        O_status=12
                        print(O_status,"- setup_location failed")
                        conn.rollback()
                        return False

            conn.commit()
            return True

    except Exception as error:
        if O_status<=2:
            print(L_func_name,":",O_status,":","Exception occured while fetching alloc_level: ", error)
        elif O_status==3:
            print(L_func_name,":",O_status,":","Exception occured while merging alloc_calc_source_temp: ", error)
        elif O_status==4:
            print(L_func_name,":",O_status,":","Exception occured while updating alloc_calc_source_temp: ", error)
        elif O_status==5:
            print(L_func_name,":",O_status,":","Exception occured while updating alloc_like_item_source: ", error)
        elif O_status==6:
            print(L_func_name,":",O_status,":","Exception occured while deleting alloc_like_item_source: ", error)
        elif O_status==7:
            print(L_func_name,":",O_status,":","Exception occured while inserting alloc_like_item_source: ", error)
        elif O_status==8:
            print(L_func_name,":",O_status,":","Exception occured while processing update_alloc function: ", error)
        elif O_status==9:
            print(L_func_name,":",O_status,":","Exception occured while fetching data from alloc_calc_allitemloc_temp: ", error)
        elif O_status==10:
            print(L_func_name,":",O_status,":","Exception occured while fetching data from alloc_rule: ", error)
        elif O_status==11:
            print(L_func_name,":",O_status,":","Exception occured while processing setup_location function: ", error)
        else:
            print(L_func_name,":",O_status,"Exception occured in: ",L_func_name,error)
        conn.rollback()
        return False

#--------------------------------------------------------------
# Function to delete mapped like items from screen
#--------------------------------------------------------------

def delete_like_item_map(conn
                         ,I_alloc
                         ,O_status):
    L_func_name ="delete_like_item_map"
    O_status = 0
    L_count = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\like_item_queries.yaml') as fh:
            queries                    = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_chk_alloc                = queries['delete_like_item_map']['Q_chk_alloc']
            Q_ins_item_sku             = queries['delete_like_item_map']['Q_ins_item_sku']
            Q_del_map_item             = queries['delete_like_item_map']['Q_del_map_item']
            Q_fetch_item_diff_temp     = queries['delete_like_item_map']['Q_fetch_item_diff_temp']
            Q_fetch_item_diff_map_temp = queries['delete_like_item_map']['Q_fetch_item_diff_map_temp']

            mycursor = conn.cursor()
            #status
            O_status = 1
            df_chk_alloc = pd.read_sql(Q_chk_alloc,conn,params=(I_alloc,))

            if df_chk_alloc.alloc_level[0] =='T':
                #status
                O_status = 2
                #Q_ins_item_sku
                mycursor.execute("select * from alloc_like_item_diff_temp  ")
                print("del tempporary alloc_like_item_diff_temp tables data", mycursor.fetchall() ,"\n\n")
                mycursor.execute(Q_ins_item_sku,(I_alloc,))
                L_count = mycursor.rowcount
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount,Q_ins_item_sku,(I_alloc,),"\n")

            #Q_del_map_item
            #status
            O_status = 3
            if L_count>0:
                mycursor.execute(Q_del_map_item,(I_alloc,))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                conn.commit()

            #dataframe
            #status
            O_status = 4
            df_item_diff_temp     = pd.read_sql(Q_fetch_item_diff_temp,conn,params=(I_alloc,))
            df_item_diff_map_temp = pd.read_sql(Q_fetch_item_diff_map_temp,conn,params=(I_alloc,))

            conn.commit()
            return df_item_diff_temp,df_item_diff_map_temp

    except Exception as error:
        if O_status<=1:
            print(L_func_name,":",O_status,":","Exception occured while retrieving data from alloc_head: ", error)
        elif O_status==2:
            print(L_func_name,":",O_status,":","Exception occured while inserting alloc_like_item_diff_temp: ", error)
        elif O_status==3:
            print(L_func_name,":",O_status,":","Exception occured while deleting alloc_like_item_diff_map_temp: ", error)
        elif O_status==4:
            print(L_func_name,":",O_status,":","Exception occured while processing output dataframe: ", error)
        else:
            print(L_func_name,":",O_status,"Exception occured in: ",L_func_name,error)
        conn.rollback()
        return False

#--------------------------------------------------------------------------------
#Created By - Naveen Ramanathan                                                 
#Purpose    - Retrieving data for like item screen                              
#---------------------------------------------------------------------------------

def RETREIVE_LIKE_ITEM_MAP(conn,I_alloc_no):
    O_status = 0
    L_fun = "RETREIVE_LIKE_ITEM_MAP"
    print("EXECUTING: ",L_fun)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\setup_like_item_queries.yaml') as fh:
            queries       = yaml.load(fh, Loader=yaml.SafeLoader)
            C_temp_tbl1   = queries['retreive_like_item_map']['C_temp_tbl1']
            C_temp_tbl2   = queries['retreive_like_item_map']['C_temp_tbl2']
            C_temp_tbl3   = queries['retreive_like_item_map']['C_temp_tbl3']
            C_alloc_level = queries['retreive_like_item_map']['C_alloc_level']
            L_del_1       = queries['retreive_like_item_map']['L_del_1']
            L_del_2       = queries['retreive_like_item_map']['L_del_2']
            L_del_3       = queries['retreive_like_item_map']['L_del_3']
            L_del_4       = queries['retreive_like_item_map']['L_del_4']
            L_ins_1       = queries['retreive_like_item_map']['L_ins_1']
            L_ins_2       = queries['retreive_like_item_map']['L_ins_2']
            L_ins_4       = queries['retreive_like_item_map']['L_ins_4']
            L_ins_5       = queries['retreive_like_item_map']['L_ins_5']
            C_left_out    = queries['retreive_like_item_map']['C_left_out']
            C_right_out   = queries['retreive_like_item_map']['C_right_out']

            mycursor = conn.cursor()

            mycursor.execute("SET sql_mode = '';")
            #status
            O_status = 1 
            mycursor.execute(C_temp_tbl1)
            mycursor.execute(C_temp_tbl2)
            mycursor.execute(C_temp_tbl3)
            #status
            O_status = 2
            df_alloc_level = pd.read_sql(C_alloc_level,conn,params=(I_alloc_no,))
            L_alloc_level = df_alloc_level.alloc_level[0]
            #status
            O_status = 3
            mycursor.execute(L_ins_1,(I_alloc_no,))
            L_rc = mycursor.rowcount
            print(O_status,"-","rows_affected: ",L_rc) 

            #if L_rc>0:
            #status
            O_status = 4
            mycursor.execute(L_del_1,(I_alloc_no,))
            print(O_status,"-","rows_affected: ",mycursor.rowcount) 
            if L_alloc_level == 'T':
                #status
                O_status = 5
                mycursor.execute(L_ins_2,(I_alloc_no,))
                print(O_status,"-","rows_affected: ",mycursor.rowcount)
                #status
                O_status = 6
                mycursor.execute(L_del_2,(I_alloc_no,))
                print(O_status,"-","rows_affected: ",mycursor.rowcount)
            #status
            O_status = 7
            mycursor.execute(L_del_3,(I_alloc_no,))
            print(O_status,"-","rows_affected: ",mycursor.rowcount)
            #status
            O_status = 8
            mycursor.execute(L_ins_4,(I_alloc_no,))
            print(O_status,"-","rows_affected: ",mycursor.rowcount)
            #status
            O_status = 9
            mycursor.execute(L_del_4,(I_alloc_no,))
            print(O_status,"-","rows_affected: ",mycursor.rowcount)
            #status
            O_status = 10
            mycursor.execute(L_ins_5,(I_alloc_no,))
            print(O_status,"-","rows_affected: ",mycursor.rowcount)

            conn.commit()
            df_left_out = pd.read_sql(C_left_out,conn,params=(I_alloc_no,))
            df_right_out = pd.read_sql(C_right_out,conn,params =(I_alloc_no,))
            return df_left_out,df_right_out
            
    except Exception as error:
        if O_status==1: 
            print(L_fun,":",O_status,":","Exception raised during temporary table creation:", error)
        elif O_status==2:
            print(L_fun,":",O_status,":","Exception raised during execution of alloc_level cursor:", error)
        elif O_status==3:
            print(L_fun,":",O_status,":","Exception raised during data insertion into alloc_item_source table:", error)
        elif O_status==4:
            print(L_fun,":",O_status,":","Exception raised during data deletion from alloc_like_item_diff_temp table:", error)
        elif O_status==5:
            print(L_fun,":",O_status,":","Exception raised during data insertion into alloc_like_item_diff_temp table:", error)
        elif O_status==6 or O_status==7:
            print(L_fun,":",O_status,":","Exception raised during data deletion from alloc_like_item_diff_temp or alloc_like_item_diff_map_temp table:", error)
        elif O_status==8:
            print(L_fun,":",O_status,":","Exception raised during data insertion into alloc_like_item_diff_map_temp table:", error)
        elif O_status==9:
            print(L_fun,":",O_status,":","Exception raised during data deletion from alloc_like_item_map_temp table:", error)
        elif O_status==10:
            print(L_fun,":",O_status,":","Exception raised during data insertion into alloc_like_item_map_temp table:", error)
        else:
            print(L_fun,":",O_status,":","Exception Occured: ", error)
        return False         
   


#--------------------------------------------------------------
# Function to populate diff details
#--------------------------------------------------------------
def get_size_dtl(conn
                 ,I_item
                 ,O_status):
    L_func_name ="get_size_dtl"
    O_status = 0
    emp_list = list()
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\like_item_queries.yaml') as fh:
            queries           = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_fetch_item_diff = queries['get_size_dtl']['Q_fetch_item_diff']

            O_status = 1
            df_size_dtl = pd.read_sql(Q_fetch_item_diff,conn,params=(I_item,))
            return df_size_dtl

    except Exception as error:
        if O_status==1:
            print(L_func_name,":",O_status,":","Exception occured while retrieving size detail: ", error)
        else:
            print(L_func_name,":",O_status,"Exception occured in: ",L_func_name,error)
        conn.rollback()
        return emp_list
