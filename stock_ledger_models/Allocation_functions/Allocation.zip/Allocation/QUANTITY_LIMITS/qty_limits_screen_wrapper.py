from ..GLOBAL_FILES.get_connection import get_mysql_conn
from .setup_qty_limits import P360_RETREIVE_QUANTITY_LIMITS
from .setup_qty_limits import P360_GET_QTY_LIMITS
import pandas as pd

#----------------------------------------------------------
# Function to call other fuctions for testing
#----------------------------------------------------------
def rtv_qty_limits(conn,I_alloc_no,I_mode):
    L_func_name="test_func"
    O_status =list()
    try:
        L_func_call = P360_RETREIVE_QUANTITY_LIMITS(conn,I_alloc_no,I_mode)
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return False




#if __name__ == "__main__":
#    I_alloc = '1757095'
#    mode = 'NEW'
#    L_func_call = rtv_qty_limits(I_alloc,mode)    
#    print(L_func_call)
