from ..GLOBAL_FILES.get_connection import get_mysql_conn
from .setup_qty_limits import P360_INSERT_QTY_LIMITS
import pandas as pd

#----------------------------------------------------------
# Function to call other fuctions for testing
#----------------------------------------------------------
def ins_qty_limits(conn,
                   I_alloc_no):
    L_func_name="ins_qty_limits"
    O_status =list()
    print("testing 123")
    try:
        L_func_call = P360_INSERT_QTY_LIMITS(conn,
                                             I_alloc_no)
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return False




#if __name__ == "__main__":
#    I_alloc_no = '1757095'
#    I_min = 0
#    I_max =0
#    I_treshold=0
#    I_trend=0
#    I_wos=0
#    I_min_need=0
#    I_item_id =0
#    I_loc_id = 0
#    L_func_call = ins_qty_limits(I_alloc_no)    
#    print(L_func_call)
