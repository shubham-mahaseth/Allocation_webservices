from ..GLOBAL_FILES.get_connection import get_mysql_conn
import pandas as pd
from asyncio.windows_events import NULL
from pickle import NONE
from ..INVENTORY_SETUP.update_alloc_ext import update_alloc
import yaml
import numpy as np

##################################################################################
#Created By - Naveen Ramanathan                                                  #
#File Name  - setup_qty_limits.py                                                #
#Purpose    - All functions related to quantity limits screen                    #
##################################################################################

def P360_RETREIVE_QUANTITY_LIMITS(conn,I_alloc_no,I_mode):
    O_status = [0]
    L_func_name="P360_RETREIVE_QUANTITY_LIMITS"
    emp = list()
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\setup_qty_limits_queries.yaml') as fh:
            queries          = yaml.load(fh, Loader=yaml.SafeLoader)
            C_temp_tbl       = queries['retreive_quantity_limits']['C_temp_tbl']
            C_alloc_level    = queries['retreive_quantity_limits']['C_alloc_level']
            C_alloc_criteria = queries['retreive_quantity_limits']['C_alloc_criteria']
            L_del_1          = queries['retreive_quantity_limits']['L_del_1']
            L_del_2          = queries['retreive_quantity_limits']['L_del_2']
            L_del_3          = queries['retreive_quantity_limits']['L_del_3']
            L_ins_1          = queries['retreive_quantity_limits']['L_ins_1']
            L_ins_2          = queries['retreive_quantity_limits']['L_ins_2']
            L_ins_3          = queries['retreive_quantity_limits']['L_ins_3']
            Q_get_qty_limit  = queries['retreive_quantity_limits']['Q_get_qty_limit']
            Q_del_tmp        = queries['retreive_quantity_limits']['Q_del_tmp']

            mycursor = conn.cursor()
            #status
            O_status = 1
            mycursor.execute(C_temp_tbl)
            #status
            O_status = 2
            df_alloc_level = pd.read_sql(C_alloc_level,conn,params=(I_alloc_no,))
            L_alloc_level = df_alloc_level.alloc_level[0]
            #status
            O_status = 3
            df_alloc_criteria = pd.read_sql(C_alloc_criteria,conn,params=(I_alloc_no,))
            L_alloc_criteria = df_alloc_criteria.alloc_criteria[0]
            #status
            O_status = 4
            if I_mode != "VIEW":
                #status
                O_status = 5 
                mycursor.execute(L_del_1,(I_alloc_no, ))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                #status
                O_status= 6
                mycursor.execute(L_del_2,(I_alloc_no, I_alloc_no))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                
                #status
                O_status=7
                mycursor.execute(L_del_3,(I_alloc_no, I_alloc_no, I_alloc_no,I_alloc_no))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                #status
                O_status=8
                #conn.commit()
                mycursor.execute(L_ins_1,(I_alloc_no, I_alloc_no))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                #status
                O_status=9
                #conn.commit()
                if L_alloc_level == 'T':
                    #status
                    O_status=10
                    #conn.commit()
                    mycursor.execute(L_ins_2,(I_alloc_no, L_alloc_criteria, L_alloc_criteria, I_alloc_no))
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                    #status
                    O_status=11
                    #conn.commit()
            if L_alloc_level == 'T':
                mycursor.execute(Q_del_tmp,(I_alloc_no,))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                O_status = 12
                mycursor.execute(L_ins_3,(I_alloc_no, I_alloc_no, I_alloc_no))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                #conn.commit()

            if I_mode != "VIEW":
                #status
                O_status=13
                if P360_GET_QTY_LIMITS(conn,I_alloc_no) == False:
                    conn.rollback()
                    #status
                    O_status=14
                    print(O_status)
                    conn.rollback()
                    return O_status            
                else:
                    #status
                    O_status=15
                    conn.commit()
            conn.commit()
            df_qty_limit_data = pd.read_sql(Q_get_qty_limit,conn,params=(I_alloc_no,)) 
            return df_qty_limit_data
    except Exception as error:
        print(error)
        #status
        O_status=16
        print(O_status)
        conn.rollback()
        return emp  #empty list


def df_conversion(data):
    res_list=[]
    rec={}
    if len(data)>0:
        data =  data.replace(np.NaN, "NULL", regex=True)
        for val2 in data.values:
            count=0
            for col4 in data.columns:
                rec[col4]=val2[count]
                count=count+1
            for col in rec:
                if rec[col]==None or rec[col]=="NULL":
                    rec[col]=""
            res_list.append(rec.copy()) 
    return res_list

##################################################################################
        
def P360_GET_QTY_LIMITS(conn,I_alloc_no):
    try: 
        O_status = [0]
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\setup_qty_limits_queries.yaml') as fh:
            queries = yaml.load(fh, Loader=yaml.SafeLoader)
            C_alloc_level = queries['get_qty_limits']['C_alloc_level']
            L_del_1 = queries['get_qty_limits']['L_del_1']
            L_ins_2 = queries['get_qty_limits']['L_ins_2']
            L_mer_1 = queries['get_qty_limits']['L_mer_1']
            mycursor = conn.cursor()
            #status
            O_status=(1) 
            df_alloc_level = pd.read_sql(C_alloc_level,conn,params=(I_alloc_no,))
            L_alloc_level = df_alloc_level.alloc_level[0]
            #status
            O_status=(1)
            #conn.commit()
            mycursor.execute(L_del_1,(I_alloc_no,))
            #status
            O_status=(1)
            #conn.commit()
            
            if L_alloc_level == 'D':
               print("CODE NEEDS TO BE ADDED FOR STYLE/DIFF ALLOCATIONS")
            else:
               mycursor.execute(L_ins_2,(I_alloc_no,))
               #status
               O_status=(1)
            #conn.commit()   
            
            if L_alloc_level == 'T':
                mycursor.execute(L_mer_1,(I_alloc_no,)) 
                #status
                O_status=(1)
                #conn.commit()
            conn.commit()    
            return True
        
    except Exception as error:
        print(error)
        #status
        O_status=(255)
        print(O_status)
        conn.rollback()
        return False     

##################################################################################
         
def P360_INSERT_QTY_LIMITS(conn,
                           I_alloc_no):
    try:   
        O_status = [0]
        rows_affected=0
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\setup_qty_limits_queries.yaml') as fh:
            queries = yaml.load(fh, Loader=yaml.SafeLoader)
            C_alloc_level  = queries['insert_qty_limits']['C_alloc_level']
            C_get_rule_rec = queries['insert_qty_limits']['C_get_rule_rec']
            L_del_1        = queries['insert_qty_limits']['L_del_1']
            L_mer_1        = queries['insert_qty_limits']['L_mer_1']
            Q_upd_inputs   = queries['insert_qty_limits']['Q_upd_inputs']

            mycursor = conn.cursor()

            #status
            O_status.append(1)
            #updating inputs
            mycursor.execute(Q_upd_inputs,(I_alloc_no,))
            rows_affected = mycursor.rowcount

            df_alloc_level = pd.read_sql(C_alloc_level,conn,params=(I_alloc_no,))
            L_alloc_level = df_alloc_level.alloc_level[0]
            #status
            O_status.append(2)
            if L_alloc_level == "T":
                #mycursor.execute(L_del_1,(I_alloc_no,)) --using upsert in L_mer_1
                if rows_affected >0: 
                    #status
                    O_status.append(3)
                    mycursor.execute(L_mer_1,(I_alloc_no,I_alloc_no)) 
                    #status
                    O_status.append(4)
                    rows_affected=mycursor.rowcount
            #conn.commit()
            if rows_affected > 0:
                L_status = list()
                I_input_data = list()
                if update_alloc(conn,
                                O_status,
                                I_alloc_no,
                                None,
                                None,
                                'Y',
                                I_input_data) ==False:
                    #status
                    O_status.append(5)
                    print(O_status)
                    conn.rollback()
                    return False
            #df_rule_row = pd.read_sql(C_get_rule_rec,conn,params=(I_alloc_no,)) 
            #L_rule_row = df_rule_row.*[0]
            if P360_GET_QTY_LIMITS(conn,I_alloc_no) == False:
                #status
                O_status.append(6)
                print(O_status)
                conn.rollback()
                return False
            #mycursor.execute(C_drop_tbl,) #for testing purposes
            conn.commit()    
            return True
        
    except Exception as error:
        print(error)
        #status
        O_status.append(255)
        print(O_status)
        conn.rollback()
        return False  

##################################################################################        