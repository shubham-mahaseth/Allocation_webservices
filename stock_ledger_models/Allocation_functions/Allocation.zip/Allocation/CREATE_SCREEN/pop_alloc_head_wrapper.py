from CREATE_SCREEN.on_click_process import populate_header
from ..GLOBAL_FILES.get_connection import get_mysql_conn


#----------------------------------------------------------
# Function to populate allocation header
#----------------------------------------------------------
def pop_alloc_head(I_alloc):

    L_func_name="pop_alloc_head"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        with get_mysql_conn (I_get_mysql_conn) as conn:
            L_func_call = populate_header(conn
                                          ,I_alloc
                                          ,O_status)
            return L_func_call

    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




#if __name__ == "__main__":
#    I_alloc = 330

#    L_func_call = pop_alloc_head(I_alloc)
#    print(L_func_call)
