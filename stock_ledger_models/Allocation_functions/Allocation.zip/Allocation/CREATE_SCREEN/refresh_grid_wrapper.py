from .on_click_process import refresh_grid
from ..GLOBAL_FILES.get_connection import get_mysql_conn


#----------------------------------------------------------
# Function to refresh all screen
#----------------------------------------------------------
def refresh_all(conn,I_alloc):

    L_func_name="pop_alloc_head"
    O_status =list()
    try:
        #I_get_mysql_conn = list()
        #I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = refresh_grid(conn
                                    ,I_alloc
                                    ,O_status)
        return L_func_call

    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




#if __name__ == "__main__":
#    I_alloc = 0

#    L_func_call = refresh_all(I_alloc)
#    print(L_func_call)

