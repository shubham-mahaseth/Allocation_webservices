from ..GLOBAL_FILES.get_connection import get_mysql_conn
from .populate_search_result import search



#----------------------------------------------------------
# Function to populate items for allocation
#----------------------------------------------------------
def populate_item(conn,I_search_criteria):
    L_func_name="populate_item"
    O_status =list()
    print("input:",I_search_criteria)
    try:
        #I_get_mysql_conn = list()
        #I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = search(conn,I_search_criteria,O_status)
        return L_func_call

    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




#if __name__ == "__main__":
#    i_search_criteria = {"WHATIF_SOURCE_TYPE_IND": 1
#                          ,"WH": []
#                          ,"WH_SOURCE_TYPE_IND": 1
#                          ,"ALLOC_NO": '123'
#                          ,"ALLOC_CRITERIA": 'W'
#                          ,"ALLOC_LEVEL": 'T'
#                          ,"ALLOC_TYPE": 'A'
#                          ,"CLEARANCE_IND": 'N'
#                          ,"DIFF_ID": []
#                          ,"MIN_AVAIL_QTY": 5
#                          ,"MAX_AVAIL_QTY": 99999999
#                          ,"HIER1":[107]
#                          ,"HIER2":[]
#                          ,"HIER3":[]
#                          ,"SUPPLIER":[]
#                          ,"SUPPLIER_SITE":[]
#                          ,"PACK_NO":[]
#                          ,"ITEM_PARENT":[]
#                          ,"SKU":[]
#                          ,"ITEM_GRANDPARENT":[]
#                          ,"ITEM_LIST":[]
#                          ,"VPN":[]
#                          ,"UDA":[]
#                          ,"UDA_VALUE":[]
#                          ,"EXCL_UDA":[]
#                          ,"EXCLUDE_UDA_VALUE":[]
#                        }

#    l_func_call = populate_item(i_search_criteria)    
#    print(l_func_call)

