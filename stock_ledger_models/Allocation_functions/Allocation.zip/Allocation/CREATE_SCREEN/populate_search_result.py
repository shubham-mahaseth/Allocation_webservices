from datetime import datetime
from sqlite3 import connect
import pandas as pd
import numpy as np
import yaml
import mysql
from ..GLOBAL_FILES.convert_numpy_64 import convert_numpy
from ..GLOBAL_FILES.null_handler import none_to_null

#############################################################
# Created By - Priyanshu Pandey                             #
# File Name - populate_search_result.py                     #
# Purpose - pupolate items on create screen                 #
#############################################################

#--------------------------------------------------------------
# Function to search items
#--------------------------------------------------------------


def search(conn
           ,I_search_criteria
           ,O_status):
    L_func_name ="search"
    O_status = 0
    emp_lis = list()
    print("EXECUTING: ",L_func_name)
    try:
        L_whatif_source_type_ind = I_search_criteria["WHATIF_SOURCE_TYPE_IND"]
        #status
        O_status = 1
        if L_whatif_source_type_ind == 1:
            #status
            O_status = 2
            if common_search(conn,
                             I_search_criteria,
                             True,
                             True,
                             O_status) == False:
                #status
                O_status = 3
                print(O_status,"--common_search")
                return emp_lis 
        else:
            if common_search(conn,
                             I_search_criteria,
                             True,
                             False,
                             O_status) == False:
                #status
                O_status = 4
                print(O_status,"--common_search")
                return emp_lis
        conn.commit()
        #status
        O_status = 5
        L_fetch_inventory = fetch_inventory(conn,
                                            I_search_criteria,
                                            O_status)
        if len(L_fetch_inventory) ==0:
            #status
            O_status = 6
            print(O_status,"No records found while executing fetch_inventory")
            conn.rollback()
            return emp_lis 
        else:
            conn.commit()
            return L_fetch_inventory

    except Exception as error:
        if O_status<=2:
            print(L_func_name,":",O_status,":","Exception occured while processing whatif common_search: ", error)
        elif O_status>=3 and O_status<=4:
            print(L_func_name,":",O_status,":","Exception occured while processing common_search: ", error)
        elif O_status<=5 and O_status>=6:
            print(L_func_name,":",O_status,":","Exception occured while processing fetch_inventory: ", error)
        else:
            print(L_func_name,":",O_status,"Exception occured in: ",L_func_name,error)
        conn.rollback()
        return emp_lis



#--------------------------------------------------------------
# Function to get search items
#--------------------------------------------------------------

def common_search(conn
                  ,I_search_criteria
                  ,I_expand_to_pack
                  ,I_what_if_ind
                  ,O_status):
    L_func_name ="common_search"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        #status
        O_status = 1
        if setup_warehouse(conn,
                           I_search_criteria,
                           I_what_if_ind,
                           O_status) ==False:
            #status
            O_status =2 
            print(O_status,"--setup_warehouse")
            return False
        #status
        O_status = 3
        L_wh_search_criteria = I_search_criteria["WH_SOURCE_TYPE_IND"]

        if L_wh_search_criteria !=None:
            #status
            O_status = 4
            #find item/loc combinations based on item criteria
            #get txn level items covered by the item criteria and whs
            #will always populate txn level items
            if get_item_locs_from_items_whs(conn,
                                            I_search_criteria,
                                            O_status) == False:
                #status
                O_status =5
                print(O_status,"--get_item_locs_from_items_whs")
                return False

            L_alloc_level = I_search_criteria["ALLOC_LEVEL"]

            if L_alloc_level == 'T':
                #status
                O_status = 6
                #MARK_ROLLUP_GROUP_PACK
                if mark_rollup_group(conn,
                                     O_status) == False:
                    #status
                    O_status =7
                    print(O_status,"--mark_rollup_group")
                    return False
            return True

    except Exception as error:
        if O_status<=2:
            print(L_func_name,":",O_status,":","Exception occured while processing setup_warehouse: ", error)
        elif O_status>=3 and O_status<=5:
            print(L_func_name,":",O_status,":","Exception occured while processing get_item_locs_from_items_whs: ", error)
        elif O_status<=6 and O_status>=7:
            print(L_func_name,":",O_status,":","Exception occured while processing mark_rollup_group: ", error)
        else:
            print(L_func_name,":",O_status,"Exception occured in: ",L_func_name,error)
        conn.rollback()
        return False

#--------------------------------------------------------------
# Function to setup warehouse
#--------------------------------------------------------------

def setup_warehouse(conn
                    ,I_search_criteria
                    ,I_what_if_ind
                    ,O_status):
    L_func_name ="setup_warehouse"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\populate_search_result_queries.yaml') as fh:
            queries                = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_create_wh_srch_table = queries['setup_warehouse']['Q_create_wh_srch_table']
            Q_chk_wh_srch_table    = queries['setup_warehouse']['Q_chk_wh_srch_table']
            Q_ins_wh_srch_tbl      = queries['setup_warehouse']['Q_ins_wh_srch_tbl']
            Q_fetch_wh             = queries['setup_warehouse']['Q_fetch_wh']

            mycursor = conn.cursor()
            mycursor.execute("set sql_mode = '';")
            L_input_wh = I_search_criteria["WH"]
            L_input_wh = convert_numpy(L_input_wh)
            #status
            O_status =1

            #Q_chk_wh_srch_table
            df_chk = pd.read_sql(Q_chk_wh_srch_table,conn)
            L_chk = df_chk.chk[0]

            #status
            O_status =2

            if L_chk == 1:
                #status
                O_status =3
                print("alloc_whs_search_temp table already exists")
                print(O_status,L_func_name)

            else: 
                #status
                O_status =4
                mycursor.execute(Q_create_wh_srch_table)

            #status
            O_status =5

            if len(L_input_wh) !=0:
                #status
                O_status =6
                for i in range(len(L_input_wh)):
                    L_wh = L_input_wh[i]

                    mycursor.execute(Q_ins_wh_srch_tbl,(L_wh,))
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
            else:
                #status
                O_status =7
                df_wh = pd.read_sql(Q_fetch_wh,conn)
                if len(df_wh)>0:
                    for i in range(len(df_wh)):
                        L_wh = df_wh.wh[i]
                        mycursor.execute(Q_ins_wh_srch_tbl,(L_wh,))
                        print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
            #status
            O_status =8
            conn.commit()
            return True


    except Exception as error:
        if O_status==1:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_chk_wh_srch_table: ", error)
        elif O_status==3:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_drop_wh_srch_tbl: ", error)
        elif O_status==4:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_create_wh_srch_table: ", error)
        elif O_status>4 and O_status<=7:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_ins_wh_srch_tbl: ", error)
        else:
            print(L_func_name,":",O_status,"Exception occured in: ",L_func_name,error)
        conn.rollback()
        return False

#--------------------------------------------------------------
# Function to get all items based on input
#--------------------------------------------------------------

def get_item_locs_from_items_whs(conn,
                                 I_search_criteria,
                                 O_status):
    L_func_name ="get_item_locs_from_items_whs"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\populate_search_result_queries.yaml') as fh:
            queries                = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_hier3_sku     = queries['get_item_locs_from_items_whs']['Q_hier3_sku']
            Q_hier2_sku     = queries['get_item_locs_from_items_whs']['Q_hier2_sku']
            Q_hier1_sku     = queries['get_item_locs_from_items_whs']['Q_hier1_sku']
            Q_input_item    = queries['get_item_locs_from_items_whs']['Q_input_item']
            Q_tran_sku      = queries['get_item_locs_from_items_whs']['Q_tran_sku']
            Q_itemlist_sku  = queries['get_item_locs_from_items_whs']['Q_itemlist_sku']
            Q_supplier_sku  = queries['get_item_locs_from_items_whs']['Q_supplier_sku']
            Q_supp_site_sku = queries['get_item_locs_from_items_whs']['Q_supp_site_sku']
            Q_vpn_sku       = queries['get_item_locs_from_items_whs']['Q_vpn_sku']
            Q_uda_sku       = queries['get_item_locs_from_items_whs']['Q_uda_sku']
            Q_excl_uda_sku  = queries['get_item_locs_from_items_whs']['Q_excl_uda_sku']
            Q_uda_val_sku   = queries['get_item_locs_from_items_whs']['Q_uda_val_sku']
            Q_excl_uda_val  = queries['get_item_locs_from_items_whs']['Q_excl_uda_val']
            #table
            Q_create_item_loc_srch_table  = queries['get_item_locs_from_items_whs']['Q_create_item_loc_srch_table']
            Q_chk_item_loc_srch_table     = queries['get_item_locs_from_items_whs']['Q_chk_item_loc_srch_table']
            Q_ins_search_item_loc         = queries['get_item_locs_from_items_whs']['Q_ins_search_item_loc']
            Q_create_item_srch_table      = queries['get_item_locs_from_items_whs']['Q_create_item_srch_table']
            Q_chk_item_srch_table         = queries['get_item_locs_from_items_whs']['Q_chk_item_srch_table']
            Q_ins_search_item             = queries['get_item_locs_from_items_whs']['Q_ins_search_item']
            Q_fetch_item_loc_srch         = queries['get_item_locs_from_items_whs']['Q_fetch_item_loc_srch']

            mycursor = conn.cursor()

            L_item_rec         = list()
            L_hier_item_rec    = list() #for hier
            L_sup_item_rec     = list() #for L_supplier
            L_supsite_item_rec = list() #for L_supplier_site
            L_pack_item_rec    = list() #for L_pack_no
            L_parent_item_rec  = list() #for L_item_parent/L_item_grandparent/L_sku
            L_sku_item_rec     = list() #for L_sku
            L_list_item_rec    = list() #for L_item_list
            L_vpn_item_rec     = list() #for L_vpn
            L_uda_item_rec     = list() #for L_uda
            L_uda_val_item_rec = list() #for L_uda_value


            #status
            O_status = 1 

            L_alloc_level      = I_search_criteria["ALLOC_LEVEL"]
            L_hier1            = I_search_criteria["HIER1"]
            L_hier2            = I_search_criteria["HIER2"]
            L_hier3            = I_search_criteria["HIER3"]
            L_supplier         = I_search_criteria["SUPPLIER"]
            L_supplier_site    = I_search_criteria["SUPPLIER_SITE"]
            #L_pack_no         = I_search_criteria["PACK_NO"]
            L_item_parent      = I_search_criteria["ITEM_PARENT"]
            L_sku              = I_search_criteria["SKU"]
            L_item_grandparent = I_search_criteria["ITEM_GRANDPARENT"]
            L_item_list        = I_search_criteria["ITEM_LIST"]
            L_vpn              = I_search_criteria["VPN"]
            L_uda              = I_search_criteria["UDA"]
            L_uda_value        = I_search_criteria["UDA_VALUE"]
            L_excl_uda         = I_search_criteria["EXCLUDE_UDA"]
            L_excl_uda_val     = I_search_criteria["EXCLUDE_UDA_VALUE"]

            #appending None to execute IN operator in queries
            if len(L_hier1) == 1:
                L_hier1.append(-1)
            if len(L_hier2) == 1:
                L_hier2.append(-1)
            if len(L_hier3) == 1:
                L_hier3.append(-1)
            if len(L_supplier) == 1:
                L_supplier.append(-1)
            if len(L_supplier_site) == 1:
                L_supplier_site.append(-1)
            #if len(L_pack_no) == 1:
            #    L_pack_no.append(None)
            if len(L_item_parent) == 1:
                L_item_parent.append(-1)
            if len(L_sku) == 1:
                L_sku.append(-1)
            if len(L_item_grandparent) == 1:
                L_item_grandparent.append(-1)
            if len(L_item_list) == 1:
                L_item_list.append(-1)
            if len(L_vpn) == 1:
                L_vpn.append(-1)
            if len(L_uda) == 1:
                L_uda.append(-1)
            if len(L_uda_value) == 1:
                L_uda_value.append(-1)
            if len(L_excl_uda) == 1:
                L_excl_uda.append(-1)
            if len(L_excl_uda_val) == 1:
                L_excl_uda_val.append(-1)

            #convert list into tuple
            L_hier1            = convert_numpy(L_hier1)
            L_hier2            = convert_numpy(L_hier2)
            L_hier3            = convert_numpy(L_hier3)
            L_supplier         = convert_numpy(L_supplier)
            L_supplier_site    = convert_numpy(L_supplier_site)
            L_item_parent      = convert_numpy(L_item_parent)
            L_sku              = convert_numpy(L_sku)
            L_item_grandparent = convert_numpy(L_item_grandparent)
            L_item_list        = convert_numpy(L_item_list)
            L_vpn              = convert_numpy(L_vpn)
            L_uda              = convert_numpy(L_uda)
            L_uda_value        = convert_numpy(L_uda_value)
            L_excl_uda         = convert_numpy(L_excl_uda)
            L_excl_uda_val     = convert_numpy(L_excl_uda_val)

            #convert none to null
            #L_hier1            = none_to_null(L_hier1)
            #L_hier2            = none_to_null(L_hier2)
            #L_hier3            = none_to_null(L_hier3)
            #L_supplier         = none_to_null(L_supplier)
            #L_supplier_site    = none_to_null(L_supplier_site)
            #L_item_parent      = none_to_null(L_item_parent)
            #L_sku              = none_to_null(L_sku)
            #L_item_grandparent = none_to_null(L_item_grandparent)
            #L_item_list        = none_to_null(L_item_list)
            #L_vpn              = none_to_null(L_vpn)
            #L_uda              = none_to_null(L_uda)
            #L_uda_value        = none_to_null(L_uda_value)
            #L_excl_uda         = none_to_null(L_excl_uda)
            #L_excl_uda_val     = none_to_null(L_excl_uda_val)
            #status
            O_status = 2

            if L_alloc_level =='T':
                if len(L_hier1) != 0 and len(L_hier2) !=0 and len(L_hier3) != 0:
                    #status
                    O_status = 3

                    #Q_hier3_sku
                    mycursor.execute(Q_hier3_sku.format(L_hier1,L_hier2,L_hier3))
                    L_result = mycursor.fetchall()

                    #status
                    O_status = 4
                    if len(L_result)>0:
                        #status
                        O_status = 5
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            L_hier_item_rec.append(Li_item)

                elif len(L_hier1) != 0 and len(L_hier2) !=0:
                    #status
                    O_status = 6

                    #Q_hier2_sku
                    mycursor.execute(Q_hier2_sku.format(L_hier1,L_hier2))
                    L_result = mycursor.fetchall()

                    #status
                    O_status = 7
                    if len(L_result)>0:
                        #status
                        O_status = 8
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            L_hier_item_rec.append(Li_item)
                        
                elif len(L_hier1) != 0:

                    #status
                    O_status = 9
                    #Q_hier1_sku
                    mycursor.execute(Q_hier1_sku.format(L_hier1))
                    L_result = mycursor.fetchall()
                    #status
                    O_status = 10

                    if len(L_result)>0:
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            L_hier_item_rec.append(Li_item)

                #status
                O_status = 11
                L_item_rec = L_hier_item_rec

                if len(L_item_parent) !=0 or len(L_item_grandparent) != 0:

                    L_null = -1
                    if len(L_item_parent) ==0:
                        L_item_parent =  L_item_parent + (L_null,) + (L_null,)
                    if len(L_item_grandparent) ==0:
                        L_item_grandparent =  (L_null,) + (L_null,)

                    #status
                    O_status = 12
                    #Q_input_item
                    mycursor.execute(Q_input_item.format(L_item_parent,L_item_grandparent))
                    L_result = mycursor.fetchall()
                    #status
                    O_status = 13

                    if len(L_result)>0:
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            L_parent_item_rec.append(Li_item)
                    #intersection
                    if len(L_item_rec)==0:
                        L_item_rec = L_parent_item_rec
                    else:
                        L_item_rec = list(set(L_hier_item_rec).intersection(set(L_parent_item_rec)))
                #status
                O_status = 14

                if len(L_sku) != 0:
                    #status
                    O_status = 12.1
                    #Q_input_item
                    print("input data ::",Q_tran_sku.format(L_sku))
                    mycursor.execute(Q_tran_sku.format(L_sku))
                    L_result = mycursor.fetchall()
                    #status
                    O_status = 13.1

                    if len(L_result)>0:
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            L_sku_item_rec.append(Li_item)
                    #intersection
                    if len(L_item_rec)==0:
                        L_item_rec = L_sku_item_rec
                    else:
                        L_item_rec = list(set(L_hier_item_rec).intersection(set(L_sku_item_rec)))
                #status
                O_status = 14.1

                if len(L_item_list) !=0:
                    #status
                    O_status = 15
                    #Q_itemlist_sku
                    mycursor.execute(Q_itemlist_sku.format(L_item_list))
                    L_result = mycursor.fetchall()
                    #status
                    O_status = 16

                    if len(L_result)>0:
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            L_list_item_rec.append(Li_item)
                    #intersection
                    if len(L_item_rec)==0:
                        L_item_rec = L_list_item_rec
                    else:
                        L_item_rec = list(set(L_item_rec).intersection(set(L_list_item_rec)))

                #status
                O_status = 17

                if len(L_supplier) !=0:
                    #status
                    O_status = 18
                    #Q_supplier_sku
                    mycursor.execute(Q_supplier_sku.format(L_supplier))
                    L_result = mycursor.fetchall()
                    #status
                    O_status = 19

                    if len(L_result)>0:
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            L_sup_item_rec.append(Li_item)

                    #intersection
                    if len(L_item_rec)==0:
                        L_item_rec = L_sup_item_rec
                    else:
                        L_item_rec = list(set(L_item_rec).intersection(set(L_sup_item_rec)))

                #status
                O_status = 20
                if len(L_supplier_site) !=0:
                    #status
                    O_status = 21
                    #Q_supp_site_sku
                    mycursor.execute(Q_supp_site_sku.format(L_supplier_site))
                    L_result = mycursor.fetchall()
                    #status
                    O_status = 22

                    if len(L_result)>0:
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            L_supsite_item_rec.append(Li_item)

                    #intersection
                    if len(L_item_rec)==0:
                        L_item_rec = L_supsite_item_rec
                    else:
                        L_item_rec = list(set(L_item_rec).intersection(set(L_supsite_item_rec)))

                #status
                O_status = 23
                if len(L_vpn) !=0:
                    #status
                    O_status = 24
                    #Q_vpn_sku
                    mycursor.execute(Q_vpn_sku.format(L_vpn))
                    L_result = mycursor.fetchall()
                    #status
                    O_status = 25

                    if len(L_result)>0:
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            L_vpn_item_rec.append(Li_item)

                    #intersection
                    if len(L_item_rec)==0:
                        L_item_rec = L_vpn_item_rec
                    else:
                        L_item_rec = list(set(L_item_rec).intersection(set(L_vpn_item_rec)))

                #status
                O_status = 26
                if len(L_uda) !=0:
                    #status
                    O_status = 27
                    #Q_uda_sku
                    mycursor.execute(Q_uda_sku.format(L_uda))
                    L_result = mycursor.fetchall()
                    #status
                    O_status = 28

                    if len(L_result)>0:
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            L_uda_item_rec.append(Li_item)

                    #intersection
                    if len(L_item_rec)==0:
                        L_item_rec = L_uda_item_rec
                    else:
                        L_item_rec = list(set(L_item_rec).intersection(set(L_uda_item_rec)))

                #status
                O_status = 29
                if len(L_uda_value) !=0:
                    #status
                    O_status = 30
                    #Q_uda_val_sku
                    mycursor.execute(Q_uda_val_sku.format(L_uda,L_uda_value))
                    L_result = mycursor.fetchall()
                    #status
                    O_status = 31

                    if len(L_result)>0:
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            L_uda_val_item_rec.append(Li_item)

                    #intersection
                    if len(L_item_rec)==0:
                        L_item_rec = L_uda_val_item_rec
                    else:
                        L_item_rec = list(set(L_item_rec).intersection(set(L_uda_val_item_rec)))

                #take common items
                #L_item_rec = list(set(list1).intersection(set(list2)).intersection(set(list3)))
                #status
                O_status = 32
                if len(L_excl_uda) !=0 and len(L_excl_uda_val) ==0:
                    #status
                    O_status = 33
                    #Q_excl_uda_sku
                    mycursor.execute(Q_excl_uda_sku.format(L_excl_uda))
                    L_result = mycursor.fetchall()
                    #status
                    O_status = 34

                    if len(L_result)>0:
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            if Li_item in L_item_rec:
                                L_item_rec.remove(Li_item)

                #status
                O_status = 35
                if len(L_excl_uda_val) !=0:
                    #status
                    O_status = 36
                    mycursor.execute(Q_excl_uda_val.format(L_excl_uda,L_excl_uda_val))
                    L_result = mycursor.fetchall()
                    #status
                    O_status = 37

                    if len(L_result)>0:
                        for i in range(len(L_result)):
                            Li_item = L_result[i]
                            Li_item = Li_item[0]
                            if Li_item in L_item_rec:
                                L_item_rec.remove(Li_item)
                
                #creating tables to insert all data
                #Q_chk_item_loc_srch_table
                df_chk = pd.read_sql(Q_chk_item_loc_srch_table,conn)
                L_chk = df_chk.chk[0]

                #status
                O_status =38

                if L_chk == 1:
                    #status
                    O_status =39
                    print("alloc_search_criteria_itm_temp table already exists")
                    print(O_status,L_func_name)
                    return False

                else: 
                    #status
                    O_status =40
                    mycursor.execute(Q_create_item_loc_srch_table)

                #Q_chk_item_srch_table
                df_chk = pd.read_sql(Q_chk_item_srch_table,conn)
                L_chk = df_chk.chk[0]

                #status
                O_status =41

                if L_chk >0:
                    #status
                    O_status =42
                    print("alloc_items_srch_temp table already exists")
                    print(O_status,L_func_name)
                    return False

                else: 
                    #status
                    O_status =43

                    mycursor.execute(Q_create_item_srch_table)

                #insering data
                L_unique_item_rec = np.unique(L_item_rec)
                if len(L_unique_item_rec)>0:
                    #status
                    O_status =44
                    for i in range(len(L_unique_item_rec)):
                        L_insert = L_unique_item_rec[i]
                        mycursor.execute(Q_ins_search_item,(L_insert,))
                        print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                    #Q_fetch_item_loc_srch
                    #status
                    O_status =45
                    df_item_loc = pd.read_sql(Q_fetch_item_loc_srch,conn)

                    if len(df_item_loc)>0:
                        for i in range(len(df_item_loc)):
                            L_item = df_item_loc.item[i]
                            L_loc = df_item_loc.wh[i]
                            #Q_ins_search_item_loc
                            mycursor.execute(Q_ins_search_item_loc,(L_item,L_loc))
                            print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
                else:
                    #status
                    O_status =46
                    print(L_func_name,O_status,": No record found")
                    print(O_status)

                conn.commit()
                return True

    except Exception as error:
        if O_status<=4:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_hier3_sku: ", error)
        elif O_status>=5 and O_status<=7:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_hier2_sku: ", error)
        elif O_status<=8 and O_status>=10:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_hier1_sku: ", error)
        elif O_status<=11 and O_status>=13:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_input_item: ", error)
        elif O_status<=14 and O_status>=16:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_itemlist_sku: ", error)
        elif O_status<=17 and O_status>=19:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_supplier_sku: ", error)
        elif O_status<=20 and O_status>=22:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_supp_site_sku: ", error)
        elif O_status<=23 and O_status>=25:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_vpn_sku: ", error)
        elif O_status<=26 and O_status>=28:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_uda_sku: ", error)
        elif O_status<=29 and O_status>=31:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_uda_val_sku: ", error)
        elif O_status<=32 and O_status>=34:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_excl_uda_sku: ", error)
        elif O_status<=35 and O_status>=37:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_excl_uda_val: ", error)
        elif O_status<=38 and O_status>=39:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_drop_item_loc_srch_tbl: ", error)
        elif O_status==40:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_create_item_loc_srch_table: ", error)
        elif O_status<=41 and O_status>=43:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_create_item_srch_table: ", error)
        elif O_status==44:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_ins_search_item: ", error)
        elif O_status==45:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_fetch_item_loc_srch: ", error)
        else:
            print(L_func_name,":",O_status,"Exception occured in: ",L_func_name,error)
        conn.rollback()
        return False


#--------------------------------------------------------------
# Function to insert rollup items
#--------------------------------------------------------------

def mark_rollup_group(conn,
                      O_status):
    L_func_name ="mark_rollup_group"
    O_status = 0
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\populate_search_result_queries.yaml') as fh:
            queries                  = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_ins_itm_srch_tmp       = queries['mark_rollup_group']['Q_ins_itm_srch_tmp']
            Q_create_item_srch_table = queries['get_item_locs_from_items_whs']['Q_create_item_srch_table']
            Q_chk_item_srch_table    = queries['get_item_locs_from_items_whs']['Q_chk_item_srch_table']
            Q_del_itm_srch_tmp       = queries['mark_rollup_group']['Q_del_itm_srch_tmp']

            #status
            O_status =1
            mycursor = conn.cursor()

            #Q_chk_item_srch_table
            df_chk = pd.read_sql(Q_chk_item_srch_table,conn)
            L_chk = df_chk.chk[0]

            #status
            O_status =2

            if L_chk >0:
                #status
                O_status =2
                print("alloc_items_srch_temp table already exists")
                print(O_status,L_func_name)
                return False
            else: 
                #status
                O_status =3

                mycursor.execute(Q_create_item_srch_table)
            
            #o_ststua
            O_status = 4
            mycursor.execute(Q_del_itm_srch_tmp)
            print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

            mycursor.execute(Q_ins_itm_srch_tmp)
            print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

            conn.commit()
            return True

    except Exception as error:
        if O_status==1:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_chk_item_srch_table: ", error)
        elif O_status==2:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_drop_item_srch_tbl: ", error)
        elif O_status==3:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_create_item_srch_table: ", error)
        elif O_status==4:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_ins_itm_srch_tmp: ", error)
        else:
            print(L_func_name,":",O_status,"Exception occured in: ",L_func_name,error)
        conn.rollback()
        return False

#--------------------------------------------------------------
# Function to populate item and location combination with inv.
#--------------------------------------------------------------

def fetch_inventory(conn,
                    I_search_criteria,
                    O_status):
    L_func_name ="fetch_inventory"
    O_status = 0
    emp_list= list()
    L_item_in_rec = list()
    print("EXECUTING: ",L_func_name)
    try:
        with open(r'.\stock_ledger_models\Allocation_functions\Allocation\GLOBAL_FILES\populate_search_result_queries.yaml') as fh:
            queries                   = yaml.load(fh, Loader=yaml.SafeLoader)
            Q_create_itm_srch_tbl     = queries['fetch_inventory']['Q_create_itm_srch_tbl']
            Q_fetch_diff_items        = queries['fetch_inventory']['Q_create_itm_srch_tbl']
            Q_fetch_diff_items        = queries['fetch_inventory']['Q_fetch_diff_items']
            Q_fetch_vpn_items         = queries['fetch_inventory']['Q_fetch_vpn_items']
            Q_del_ext_item            = queries['fetch_inventory']['Q_del_ext_item']
            Q_ins_itm_srch_dtl_tmp    = queries['fetch_inventory']['Q_ins_itm_srch_dtl_tmp']
            Q_ins_itm_srch_dtl_whatif = queries['fetch_inventory']['Q_ins_itm_srch_dtl_whatif']
            Q_ins_itm_srch_dtl        = queries['fetch_inventory']['Q_ins_itm_srch_dtl']
            Q_del_item_srch_dtl       = queries['fetch_inventory']['Q_del_item_srch_dtl']
            Q_del_item_srch_dtl_tmp   = queries['fetch_inventory']['Q_del_item_srch_dtl_tmp']
            Q_fetch_items             = queries['fetch_inventory']['Q_fetch_items']

            mycursor = conn.cursor()
            #status
            O_status = 1

            L_wh_source_type_ind = I_search_criteria["WH_SOURCE_TYPE_IND"]
            L_wi_source_type_ind = I_search_criteria["WHATIF_SOURCE_TYPE_IND"]
            L_alloc_no           = I_search_criteria["ALLOC_NO"]
            L_alloc_criteria     = I_search_criteria["ALLOC_CRITERIA"]
            L_alloc_type         = I_search_criteria["ALLOC_TYPE"]
            L_alloc_level        = I_search_criteria["ALLOC_LEVEL"]
            L_clearance_ind      = I_search_criteria["CLEARANCE_IND"]
            L_alloc_vpn          = I_search_criteria["VPN"]
            L_min_avail_qty      = I_search_criteria["MIN_AVAIL_QTY"]
            L_max_avail_qty      = I_search_criteria["MAX_AVAIL_QTY"]
            L_diff_id            = I_search_criteria["DIFF_ID"]
            #status
            O_status = 2
            if isinstance(L_alloc_no, str) == True:
                print("Input allocation number should be numeric")
                return emp_list
            #creating table
            mycursor.execute(Q_create_itm_srch_tbl)

            if L_wh_source_type_ind ==1 or L_wi_source_type_ind==1:
                #status
                O_status = 3
                if len(L_alloc_vpn) !=0:
                    #status
                    O_status = 4
                    for i in range(len(L_alloc_vpn)):
                        L_vpn = L_alloc_vpn[i]
                        #Q_fetch_vpn_items
                        df_vpn_item = pd.read_sql(Q_fetch_vpn_items,conn,params=(L_vpn,))
                        if len(df_vpn_item)>0:
                            for i in range(len(df_vpn_item)):
                                L_item = df_vpn_item.item[i]
                                L_item_in_rec.append(L_item)
                                
                if len(L_diff_id) !=0:
                    #status
                    O_status = 5
                    for i in range(len(L_diff_id)):
                        L_diff = L_diff_id[i]
                        #Q_fetch_diff_items
                        df_diff_item = pd.read_sql(Q_fetch_diff_items,conn,params=(L_diff,))
                        if len(df_diff_item)>0:
                            for i in range(len(df_diff_item)):
                                L_item = df_diff_item.item[i]
                                L_item_in_rec.append(L_item)
                
                #status
                O_status = 5.5
                if len(L_item_in_rec)>0:
                    L_unique_item = np.unique(L_item_in_rec)
                    L_unique_item= convert_numpy(L_unique_item)
                    if len(L_unique_item) == 1:
                        L_unique_item =  L_unique_item + (-1,)
                    #Q_del_ext_item
                    #status
                    O_status = 6
                    mycursor.execute(Q_del_ext_item.format(L_unique_item))
                    print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)                        
                    conn.commit()
                
                #status
                O_status = 7
                #######################################inventory setup execution############################################
                #Q_del_item_srch_dtl
                mycursor.execute(Q_del_item_srch_dtl_tmp,(L_alloc_no,))
                print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                if L_alloc_level == 'T':
                    #FOR WAREHOUSE
                    if L_alloc_criteria =='W':
                        #status
                        O_status = 8
                        #Q_ins_itm_srch_dtl 
                        mycursor.execute(Q_ins_itm_srch_dtl_tmp,(L_alloc_no,L_alloc_criteria,L_alloc_type,L_clearance_ind,L_min_avail_qty,L_max_avail_qty))
                        conn.commit()
                        print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

                    #FOR WHATIF
                    if L_alloc_criteria =='F':
                        #status
                        O_status = 8 
                        mycursor.execute(Q_ins_itm_srch_dtl_whatif,(L_alloc_no,L_alloc_criteria,L_alloc_type,L_clearance_ind))
                        conn.commit()
                        print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
            #status
            O_status = 9
            mycursor.execute(Q_del_item_srch_dtl,(L_alloc_no,))
            print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)

            #status
            O_status = 10
            mycursor.execute(Q_ins_itm_srch_dtl,(L_alloc_no,))
            print(L_func_name,"-",O_status,"-","rows_affected: ",mycursor.rowcount)
            conn.commit()

            df_result = pd.read_sql(Q_fetch_items,conn,params=(L_alloc_no,))

            return df_result
                
    except Exception as error:
        if O_status<=4:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_fetch_vpn_items: ", error)
        elif O_status==5:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_fetch_diff_items: ", error)
        elif O_status==6:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_del_ext_item: ", error)
        elif O_status==7:
            print(L_func_name,":",O_status,":","Exception occured while processing Q_ins_itm_srch_dtl: ", error)
        else:
            print(L_func_name,":",O_status,"Exception occured in: ",L_func_name,error)
        conn.rollback()        
        return emp_list