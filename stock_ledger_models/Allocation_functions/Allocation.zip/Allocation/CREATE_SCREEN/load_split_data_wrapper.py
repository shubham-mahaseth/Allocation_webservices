from GLOBAL_FILES.get_connection import get_mysql_conn
from CREATE_SCREEN.load_split_data import load_split

def to_call_ls_fun(I_alloc_no):
    L_func_name = "to_call_ls_fun"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        with get_mysql_conn (I_get_mysql_conn) as conn:
            L_func_call = load_split(conn,I_alloc_no,O_status)
            print("load_split: ",L_func_call)
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return False

#to_call_ls_fun('12345678')




