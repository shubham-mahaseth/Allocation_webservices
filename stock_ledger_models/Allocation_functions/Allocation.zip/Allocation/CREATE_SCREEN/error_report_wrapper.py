from ..CREATE_SCREEN.on_click_process import populate_error
from ..GLOBAL_FILES.get_connection import get_mysql_conn


#----------------------------------------------------------
# Function to populate allocation header
#----------------------------------------------------------
def pop_error(conn,I_alloc,I_err1,I_err2,I_err3,I_err4,I_err5,I_to_date,I_from_date):

    L_func_name="pop_error"
    O_status =list()
    try:
        #I_get_mysql_conn = list()
        #I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call =populate_error (conn,
                                        I_alloc,
                                        I_err1,
                                        I_err2,
                                        I_err3,
                                        I_err4,
                                        I_err5,
                                        I_to_date,
                                        I_from_date,
                                        O_status)
        return L_func_call

    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




#if __name__ == "__main__":
#    I_alloc = 1702
#    I_err1 = ''
#    I_err2 = ''
#    I_err3 = ''
#    I_err4 = ''
#    I_err5 = ''
#    I_to_date = None
#    I_from_date = None

#    L_func_call = pop_error(I_alloc,I_err1,I_err2,I_err3,I_err4,I_err5,I_to_date,I_from_date)
#    print(L_func_call)

