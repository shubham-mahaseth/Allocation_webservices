import mysql.connector
#from get_connection import get_mysql_conn
from .alloc_wisummary import retreive_wisummary_into_temp
from datetime import timedelta, date

def submit_wis_dtls(conn,I_search):
    L_func_name = "submit_wis_dtls"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_rwd_func_call = retreive_wisummary_into_temp(conn,I_search,O_status)
        return L_rwd_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return False

#I_search = {"I_alloc_no" : '1918351',
#			"I_multi_wh" : 'N'}

#wis_dtls(I_search)

