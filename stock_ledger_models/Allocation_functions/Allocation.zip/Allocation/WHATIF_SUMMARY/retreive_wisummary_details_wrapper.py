import mysql.connector
from .alloc_wisummary import retreive_wisummary_details
from datetime import timedelta, date

def retreive_wis_dtls(conn,I_search):
    L_func_name = "retreive_wis_dtls"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        print(conn,I_search)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_rwd_func_call = retreive_wisummary_details(conn,I_search,O_status)
        return L_rwd_func_call
        #print("L_rwd_func_call: ",L_rwd_func_call)
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        conn.rollback()
        return False

#I_search = {"I_alloc_no" : '1918351',
#			"I_po_type"  : 'WH',
#			"I_multi_wh" : 'N'}

#wis_dtls(I_search)
