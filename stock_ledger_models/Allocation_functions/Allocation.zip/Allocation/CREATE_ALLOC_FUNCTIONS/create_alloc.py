import mysql.connector
import pandas as pd
import yaml
from datetime import date
from ..GLOBAL_FILES.get_connection import get_mysql_conn
from ..CREATE_ALLOC_FUNCTIONS.insert_alloc_sku_head_alloc_dtl import insert_tables
from ..CREATE_ALLOC_FUNCTIONS.complete_create import complete_create

def create_alloc(conn,O_status,I_alloc_no,I_status):
    L_func_name = "create_alloc"
    O_status = 0
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)

        mycursor=conn.cursor()

        O_status = 1
        #I_status = ['A','R'] 
        if I_status == None:
            print("Invalid parameters")
            return False

        if I_status not in ['APV','RSV']:
            print("Invalid parameters1")
            return False

        O_status = 2
        mycursor.execute("unlock tables;")
        L_fun = insert_tables(conn,O_status,I_alloc_no)
        if L_fun == False:
            print("print success of insert tables")
            return False    
            
        O_status = 3
        L_fun_1 = complete_create(conn,O_status,I_alloc_no,'Y')
        if L_fun_1 == False:
            return False

        return True
            
    except Exception as error:
        if O_status == 1:
            print(L_func_name,":",O_status,":","Exception occured while checking the I_status  ", error)
        elif O_status == 2:
            print(L_func_name,":",O_status,":","Exception occured before calling insert_table function ", error)
        elif O_status == 3:
            print(L_func_name,":",O_status,":","Exception occured before calling complete_create function ", error)
        else:
            print(L_func_name,":",O_status,":","Exception occured: ", error)
        conn.rollback()
        return False



#if __name__ == "__main__":
#    I_alloc_no=332
#    I_status = 'A'
#    O_status=None
#    conn=None
#    daily_view = create_alloc(conn,O_status,I_alloc_no,I_status)  
#    print(daily_view);


