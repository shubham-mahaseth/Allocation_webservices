from GLOBAL_FILES.get_connection import get_mysql_conn
from setup_alloc_details import spread_alloc_loc_dtl

#----------------------------------------------------------
# Function to call spread_alloc_loc_dtl
#----------------------------------------------------------
def sprd_alloc_loc(I_alloc_no):
    L_func_name="sprd_alloc_loc"
    O_status =list()
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        with get_mysql_conn (I_get_mysql_conn) as conn:
            L_func_call = spread_alloc_loc_dtl(conn,
                                               I_alloc_no,
                                               O_status)
            return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




if __name__ == "__main__":
    I_alloc = '12345678'
    L_func_call = sprd_alloc_loc(I_alloc)    
    print(L_func_call)