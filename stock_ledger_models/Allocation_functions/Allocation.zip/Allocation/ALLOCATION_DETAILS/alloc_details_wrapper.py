#from GLOBAL_FILES.get_connection import get_mysql_conn
from .setup_alloc_details import retreive_alloc_details

#----------------------------------------------------------
# Function to call other fuctions for testing
#----------------------------------------------------------
def RTV_ALLOC_DTL(conn,I_alloc_no):
    L_func_name="RTV_ALLOC_DTL"
    O_status =list()
    try:
        #I_get_mysql_conn = list()
        #I_get_mysql_conn.append(0)
        #with get_mysql_conn (I_get_mysql_conn) as conn:
        L_func_call = retreive_alloc_details(conn,I_alloc_no)
        print("inside retv Alloc_details : ",L_func_call)
        return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return O_status




#if __name__ == "__main__":
#    I_alloc = '1921'
#    L_func_call = RTV_ALLOC_DTL(I_alloc)    
#    print(L_func_call)
