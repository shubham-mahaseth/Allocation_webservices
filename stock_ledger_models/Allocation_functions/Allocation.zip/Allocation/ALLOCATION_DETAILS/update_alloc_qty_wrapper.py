from GLOBAL_FILES.get_connection import get_mysql_conn
from setup_alloc_details import update_alloc_qty_dtl
import pandas as pd

#----------------------------------------------------------
# Function to call update_alloc_qty_dtl
#----------------------------------------------------------
def upd_sku_calc(I_alloc_no):
    L_func_name="upd_sku_calc"
    try:
        I_get_mysql_conn = list()
        I_get_mysql_conn.append(0)
        with get_mysql_conn (I_get_mysql_conn) as conn:
            L_func_call = update_alloc_qty_dtl(conn,
                                               I_alloc_no)
            return L_func_call
    except Exception as argument:
        print("Exception occured in: ",L_func_name,argument)
        return False




if __name__ == "__main__":
    I_alloc = '1918351'
    L_func_call = upd_sku_calc(I_alloc)    
    print(L_func_call)
